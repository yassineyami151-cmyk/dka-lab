#!/usr/bin/env python3
"""DKA Lab v0.2 local host. Standard-library only; RA-1.3.3 source stays untouched."""
from __future__ import annotations
import hashlib, importlib.util, json, pathlib, threading, traceback, os
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse

ROOT = pathlib.Path(__file__).resolve().parent
ENGINE_PATH = ROOT / 'engines' / 'DYNAMIC_KNOWLEDGE_ARCHITECTURE_RA1_3_3_EXPLICIT_ABSTENTION.py'
EXPECTED_REFERENCE_SHA256 = 'beb566fbbb6e7bfd86848bb4b4f86393ef375d5672b3028d62bd6cfb86c6b5a9'
actual_hash = hashlib.sha256(ENGINE_PATH.read_bytes()).hexdigest()
if actual_hash != EXPECTED_REFERENCE_SHA256:
    raise RuntimeError(f'Frozen RA-1.3.3 integrity check failed: {actual_hash}')
spec = importlib.util.spec_from_file_location('dka_frozen_ra133', ENGINE_PATH)
engine_module = importlib.util.module_from_spec(spec)
import sys
sys.modules[spec.name] = engine_module
spec.loader.exec_module(engine_module)
engine = engine_module.ReferenceEngine()
step_counter = 0
lock = threading.RLock()
run_log = []

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)
    def log_message(self, fmt, *args):
        print('[HTTP]', fmt % args)
    def send_json(self, code, data):
        raw = json.dumps(data, ensure_ascii=False, default=lambda o: getattr(o, '__dict__', str(o))).encode()
        self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(raw))); self.send_header('Cache-Control','no-store')
        self.send_header('Access-Control-Allow-Origin','*')
        self.end_headers(); self.wfile.write(raw)
    def do_OPTIONS(self):
        self.send_response(204); self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS'); self.send_header('Access-Control-Allow-Headers','Content-Type'); self.end_headers()
    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/api/health':
            return self.send_json(200, {'status':'ok','lab_version':'0.2','engine_id':'dka.ra-1.3.3','engine_version':engine.VERSION,
                'architecture_id':engine.ARCHITECTURE,'reference_sha256':actual_hash,'reference_frozen':True,
                'config_hash':engine.config_hash(),'fingerprint':engine.fingerprint(),'capabilities':['initialize','run','observe','reset'],
                'learn':False,'note':'RA-1.3.3 has no explicit feedback-learning API; feedback learning is not claimed.'})
        if path == '/api/engines':
            return self.send_json(200, {'engines':[{'id':'dka.ra-1.3.3','name':'DKA RA-1.3.3 (frozen reference)','status':'loaded','mutable':False,
                'capabilities':['run','observe','reset'],'learn':False,'sha256':actual_hash},
                {'id':'experimental.capability-loop-v2','name':'Capability Loop V2 (experimental)','status':'source-present-not-loaded','mutable':True,
                'capabilities':['experimental-code-present'],'learn':False,'warning':'Not connected to the live runtime; prior closure shows partial results only.'}]})
        if path == '/api/log': return self.send_json(200, {'runs':run_log[-100:]})
        if path in ('/','/index.html'): self.path='/index.html'
        return super().do_GET()
    def do_POST(self):
        global engine, step_counter
        path=urlparse(self.path).path
        try:
            n=int(self.headers.get('Content-Length','0'))
            if n > 1_000_000: return self.send_json(413, {'error':'Request too large (1 MB limit)'})
            body=json.loads(self.rfile.read(n) or b'{}')
            if path == '/api/reset':
                with lock:
                    engine=engine_module.ReferenceEngine(); step_counter=0
                return self.send_json(200, {'status':'reset','engine_version':engine.VERSION,'config_hash':engine.config_hash(),'reference_sha256':actual_hash})
            if path == '/api/run':
                requested_engine = body.get('engine_id', 'dka.ra-1.3.3')
                if requested_engine != 'dka.ra-1.3.3':
                    return self.send_json(501, {'error':'This engine slot is not live-wired. Add a dedicated adapter implementing PLUGIN_CONTRACT.md; the experimental V2 source is not a runnable plug-in by itself.'})
                obs=body.get('observations')
                if not isinstance(obs,list) or not obs: return self.send_json(400, {'error':'observations must be a non-empty JSON array'})
                if len(obs)>500: return self.send_json(400, {'error':'Maximum 500 observations per step'})
                parsed=[]
                for i,row in enumerate(obs):
                    if not isinstance(row,dict) or not all(k in row for k in ('subject','predicate','value')):
                        return self.send_json(400, {'error':f'observation {i} needs subject, predicate, value'})
                    strength=float(row.get('strength',1.0))
                    if not 0 <= strength <= 1: return self.send_json(400, {'error':f'observation {i} strength must be 0..1'})
                    parsed.append(engine_module.Observation(subject=str(row['subject']),predicate=str(row['predicate']),value=row['value'],
                        strength=strength,source=str(row.get('source','lab_input')),timestamp=int(row.get('timestamp',0)),role=str(row.get('role','candidate'))))
                with lock:
                    if body.get('objective'): engine.governor.set_objective(str(body['objective']))
                    idx=step_counter; directive=engine.step(parsed,idx); step_counter+=1
                    rec=engine.trace[-1]
                    out={'run_id':f'RA133-{idx+1:05d}','engine_id':'dka.ra-1.3.3','engine_version':engine.VERSION,
                        'architecture_id':engine.ARCHITECTURE,'reference_sha256':actual_hash,'config_hash':engine.config_hash(),
                        'fingerprint':engine.fingerprint(),'step':idx,
                        'directive':{'target':directive.target,'objective':directive.objective,'priority':directive.priority,'reason':directive.reason,'step':directive.step},
                        'trace':{'observation_count':rec.observation_count,'memory_size':rec.memory_size,'relation_count':rec.relation_count,
                            'best_relation':rec.best_relation,'noise':rec.noise,'forgetting_lambda':rec.forgetting_lambda,
                            'linear_score':rec.linear_score,'nonlinear_score':rec.nonlinear_score,'reassessed':rec.reassessed,'contradictions':rec.contradictions},
                        'capabilities':{'run':True,'observe':True,'reset':True,'learn':False},
                        'learning_claim':'NOT_SUPPORTED_BY_REFERENCE_API','status':'executed_by_frozen_reference'}
                    run_log.append(out)
                return self.send_json(200,out)
            return self.send_json(404, {'error':'unknown API route'})
        except Exception as e:
            traceback.print_exc(); return self.send_json(500, {'error':str(e)})

if __name__=='__main__':
    port = int(os.environ.get('PORT', '8765'))
    print(f'DKA Lab v0.2 — listening on 0.0.0.0:{port}')
    print('Frozen reference SHA-256 verified:', actual_hash)
    ThreadingHTTPServer(('0.0.0.0', port),Handler).serve_forever()
