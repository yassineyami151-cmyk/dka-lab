import hashlib, importlib.util, json, pathlib, subprocess, sys, time, urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[1]
EXPECTED='beb566fbbb6e7bfd86848bb4b4f86393ef375d5672b3028d62bd6cfb86c6b5a9'
engine_path=ROOT/'engines'/'DYNAMIC_KNOWLEDGE_ARCHITECTURE_RA1_3_3_EXPLICIT_ABSTENTION.py'
actual=hashlib.sha256(engine_path.read_bytes()).hexdigest()
assert actual==EXPECTED,(actual,EXPECTED)
spec=importlib.util.spec_from_file_location('ra133_smoke',engine_path);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
report=m.self_test(); assert report['status']=='PASS',report
p=subprocess.Popen([sys.executable,str(ROOT/'server.py')],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
try:
    for _ in range(40):
        try:
            with urllib.request.urlopen('http://127.0.0.1:8765/api/health',timeout=1) as r: health=json.loads(r.read())
            break
        except Exception: time.sleep(.15)
    else: raise RuntimeError('server did not start')
    assert health['reference_sha256']==EXPECTED and health['reference_frozen'] is True
    payload={'objective':'select candidate','observations':[
      {'subject':'task','predicate':'goal','value':'select candidate','strength':.99,'role':'evidence'},
      {'subject':'A','predicate':'supports','value':'goal','strength':.8,'role':'candidate'},
      {'subject':'B','predicate':'supports','value':'goal','strength':.9,'role':'candidate'}]}
    req=urllib.request.Request('http://127.0.0.1:8765/api/run',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'},method='POST')
    with urllib.request.urlopen(req,timeout=3) as r: out=json.loads(r.read())
    assert out['status']=='executed_by_frozen_reference',out
    assert out['directive']['target'] and out['learning_claim']=='NOT_SUPPORTED_BY_REFERENCE_API'
    print(json.dumps({'status':'PASS','reference_sha256':actual,'reference_self_test':report['status'],'api_health':'PASS','real_engine_step':'PASS','learning_claim_honest':True,'directive':out['directive']},indent=2))
finally:
    p.terminate()
    try:p.wait(timeout=3)
    except subprocess.TimeoutExpired:p.kill()
