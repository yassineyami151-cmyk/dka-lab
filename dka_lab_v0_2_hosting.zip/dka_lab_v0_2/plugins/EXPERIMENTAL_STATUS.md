# Experimental capability loop status — preserved from the Library

The V2 branch and its V4 dependency are included for traceability, but are **not loaded into the live lab runtime**. This is deliberate: the last recorded closure reported 7/12 successful full loops, 0 false successes, 3 over-abstentions and 2 appropriate abstentions; feedback was stored in memory but causal improvement on later decisions was not demonstrated. Keep it experimental and separate from frozen RA-1.3.3.

To make an experimental engine runnable in the lab, create a dedicated adapter and validate it through the hidden tests and independent evaluator first. Inclusion of source code is not equivalent to adoption or demonstrated capability.
