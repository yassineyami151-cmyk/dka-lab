#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SUN DYNAMIC ARCHITECTURE — REFERENCE ENGINE RA-1.0
==================================================
Single frozen reference engine for Governor/AAA architectural experiments.

RULE: tests may change only their scenario/input stream. They must not replace
or modify the internal architecture components.

Architecture:
Governor -> Observe -> Reason -> Directive
              ^
              |
      Memory <-> AAA <-> Linear/Nonlinear
              ^
              |
          Noise / Spiral

AAA = Analysis + Audit + Association
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple
import hashlib, json, math, random, pathlib

REFERENCE_ENGINE_VERSION = "RA-1.3.3-EXPLICIT-ABSTENTION"
EXPERIMENTAL_BRANCH_ID = "RA133-DKA-CAPABILITY-SEMANTIC-REPAIR-EXPERIMENTAL"
ARCHITECTURE_ID = "GOVERNOR-AAA-MEMORY-DYNAMIC"
DEFAULT_SEED = 73019

@dataclass(frozen=True)
class ReferenceConfig:
    seed: int = DEFAULT_SEED
    frustration_threshold: float = 3.0
    memory_capacity: int = 256
    base_retention: float = 0.985
    forgetting_floor: float = 0.08
    forgetting_rate: float = 0.035
    association_threshold: float = 0.28
    audit_penalty: float = 0.12
    contradiction_penalty: float = 0.22
    novelty_bonus: float = 0.06
    linear_weight: float = 0.45
    nonlinear_weight: float = 0.55
    spiral_step: float = 1.0
    spiral_turn: float = math.pi / 2.0
    noise_floor: float = 0.02
    noise_ceiling: float = 0.35
    reassessment_gain: float = 0.35
    max_steps: int = 256
    danger_cost_threshold: float = 0.80
    danger_priority_gain: float = 1.50
    expected_loss_trigger: float = 0.80
    irreversible_danger_floor: float = 0.50

@dataclass
class Observation:
    subject: str
    predicate: str
    value: Any
    strength: float = 1.0
    source: str = "environment"
    timestamp: int = 0
    role: str = "candidate"  # candidate = selectable target; evidence = supporting context

@dataclass
class MemoryItem:
    subject: str
    predicate: str
    value: Any
    confidence: float
    last_seen: int
    uses: int = 0
    contradictions: int = 0
    origin: str = "observation"
    role: str = "candidate"
    @property
    def key(self): return (self.subject, self.predicate)

@dataclass
class Relation:
    left: Tuple[str, str]
    right: Tuple[str, str]
    score: float
    evidence: int = 1
    active: bool = True
    last_reassessed: int = 0

@dataclass
class Directive:
    target: str
    objective: str
    priority: float
    reason: str
    step: int

@dataclass
class StepRecord:
    step: int
    observation_count: int
    memory_size: int
    relation_count: int
    best_relation: float
    noise: float
    forgetting_lambda: float
    linear_score: float
    nonlinear_score: float
    directive_target: str
    directive_objective: str
    reassessed: int
    contradictions: int

@dataclass
class RunResult:
    engine_version: str
    architecture_id: str
    seed: int
    scenario: str
    config_hash: str
    steps: List[StepRecord]
    final_directive: Optional[Directive]
    success: bool
    metrics: Dict[str, float]
    notes: List[str] = field(default_factory=list)
    def to_json(self):
        return json.dumps({
            "engine_version": self.engine_version,
            "architecture_id": self.architecture_id,
            "seed": self.seed,
            "scenario": self.scenario,
            "config_hash": self.config_hash,
            "success": self.success,
            "metrics": self.metrics,
            "notes": self.notes,
            "final_directive": asdict(self.final_directive) if self.final_directive else None,
            "steps": [asdict(x) for x in self.steps],
        }, ensure_ascii=False, indent=2)

class ReferenceMemory:
    """Persistent relational memory with fixed dynamic-forgetting policy."""
    def __init__(self, cfg):
        self.cfg = cfg
        self.items: Dict[Tuple[str,str], MemoryItem] = {}
        self.relations: Dict[Tuple[Tuple[str,str],Tuple[str,str]], Relation] = {}
        # EXPERIMENTAL ONLY: aggregate delayed feedback by the feature observed
        # for the same example. This state is not present in frozen RA-1.3.3.
        self.feedback_stats: Dict[str, Dict[str, float]] = {}
        # EXPERIMENTAL ONLY: outcome statistics keyed by an observed abstract mechanism.
        # The descriptor must be present in observations; the engine does not invent it.
        self.mechanism_feedback_stats: Dict[str, Dict[str, float]] = {}

    def record_feedback(self, subject, outcome):
        feature_item = self.items.get((subject, 'feature'))
        if feature_item is None:
            return False
        feature = str(feature_item.value)
        label = str(outcome).strip().lower()
        if label not in {'success', 'failure'}:
            return False
        row = self.feedback_stats.setdefault(feature, {'success': 0.0, 'failure': 0.0, 'n': 0.0})
        row[label] += 1.0
        row['n'] += 1.0
        return True

    def record_mechanism_feedback(self, mechanism, outcome):
        """Record outcome against an observed reusable mechanism descriptor."""
        label = str(outcome).strip().lower()
        if label not in {'success', 'failure'}:
            return False
        key = str(mechanism)
        row = self.mechanism_feedback_stats.setdefault(key, {'success': 0.0, 'failure': 0.0, 'n': 0.0})
        row[label] += 1.0
        row['n'] += 1.0
        return True

    def observe(self, obs, step):
        key = (obs.subject, obs.predicate)
        if key not in self.items:
            if len(self.items) >= self.cfg.memory_capacity:
                self._evict_lowest()
            self.items[key] = MemoryItem(obs.subject, obs.predicate, obs.value,
                                         max(0.0,min(1.0,obs.strength)), step,
                                         role=obs.role)
            return
        item = self.items[key]
        if item.value != obs.value:
            item.contradictions += 1
            item.confidence *= (1.0-self.cfg.contradiction_penalty)
        else:
            item.confidence += (1.0-item.confidence)*0.30*obs.strength
        item.value, item.last_seen, item.uses = obs.value, step, item.uses+1
        item.role = obs.role

    def _evict_lowest(self):
        """Experimental selective eviction: prefer weak, unlinked evidence over candidate anchors."""
        if not self.items: return
        linked={k for r in self.relations.values() if r.active for k in (r.left,r.right)}
        pool=[k for k,v in self.items.items() if v.role=='evidence' and k not in linked]
        if not pool: pool=[k for k,v in self.items.items() if v.role=='evidence']
        if not pool: pool=[k for k in self.items if k not in linked]
        if not pool: pool=list(self.items)
        victim=min(pool,key=lambda k:(self.items[k].confidence,self.items[k].uses))
        del self.items[victim]
        # Invariant: no stored relation may point to an absent memory item.
        # Delete rather than merely deactivate to prevent unbounded stale-relation growth.
        for rk, relation in list(self.relations.items()):
            if victim in (relation.left, relation.right):
                del self.relations[rk]

    @staticmethod
    def _compat(a,b):
        if a == b: return 1.0
        if isinstance(a,(int,float)) and isinstance(b,(int,float)):
            return 1.0/(1.0+abs(float(a)-float(b)))
        sa=set(str(a).lower().replace(',',' ').split())
        sb=set(str(b).lower().replace(',',' ').split())
        return len(sa&sb)/len(sa|sb) if sa and sb else 0.0

    def add_relation(self,left,right,score,step):
        if left == right: return
        key=tuple(sorted((left,right)))
        if key not in self.relations:
            self.relations[key]=Relation(key[0],key[1],max(0,min(1,score)),1,True,step)
        else:
            r=self.relations[key]
            r.score=max(0,min(1,0.65*r.score+0.35*score))
            r.evidence += 1; r.last_reassessed=step; r.active=True

    def dynamic_forgetting(self,step,frustration):
        """Experimental gradual decay: linked candidate anchors decay more slowly, not forever."""
        pressure=max(0,min(1,frustration/10.0))
        lam=max(self.cfg.forgetting_floor,
                min(.999,self.cfg.base_retention-self.cfg.forgetting_rate*pressure))
        linked={k for r in self.relations.values() if r.active for k in (r.left,r.right)}
        for k,item in list(self.items.items()):
            # Incremental decay: dynamic_forgetting is invoked each step. Applying
            # accumulated age at every invocation compounds decay super-linearly.
            factor=0.25 if (k in linked and item.role=='candidate') else 1.0
            item.confidence *= lam ** factor
        stale=[k for k,v in self.items.items()
               if v.confidence<.015 and step-v.last_seen>8
               and not (k in linked and v.role=='candidate')]
        for k in stale:
            del self.items[k]
        if stale:
            stale_set=set(stale)
            for rk, relation in list(self.relations.items()):
                if relation.left in stale_set or relation.right in stale_set:
                    del self.relations[rk]
        return lam

    def reassess_relations(self,step):
        changed=0
        for r in self.relations.values():
            if r.left not in self.items or r.right not in self.items:
                r.active=False; continue
            a,b=self.items[r.left],self.items[r.right]
            new=self._compat(a.value,b.value)
            old=r.score
            r.score=(1-self.cfg.reassessment_gain)*old+self.cfg.reassessment_gain*new
            r.last_reassessed=step; r.active=r.score>=.03
            if abs(r.score-old)>.05: changed+=1
        return changed

    def strongest_relation(self):
        vals=[r.score for r in self.relations.values() if r.active]
        return max(vals) if vals else 0.0

class AAA:
    def __init__(self,cfg): self.cfg=cfg
    def analysis(self,obs,memory):
        if not obs:return {"novelty":0.0,"coherence":0.0}
        known=sum((o.subject,o.predicate) in memory.items for o in obs)
        novelty=1-known/len(obs)
        unique=len(set(str(o.value) for o in obs))
        return {"novelty":novelty,"coherence":1/max(1,unique)}
    def audit(self,obs,memory):
        # Audit against pre-update memory and retain the causal evidence, not only a count.
        conflicts=[]
        for o in obs:
            key=(o.subject,o.predicate)
            prior=memory.items.get(key)
            if prior is not None and prior.value != o.value:
                conflicts.append({
                    "key": key,
                    "old_value": prior.value,
                    "new_value": o.value,
                    "source": o.source,
                    "strength": max(0.0,min(1.0,float(o.strength))),
                    "role": o.role,
                })
        contradictions=len(conflicts)
        rate=contradictions/max(1,len(obs))
        return {"contradictions":float(contradictions),
                "audit_score":max(0,1-rate*self.cfg.audit_penalty*5),
                "conflicts":conflicts}
    def association(self,obs,memory,step):
        keys=[(o.subject,o.predicate) for o in obs if (o.subject,o.predicate) in memory.items]
        created=0
        for i in range(len(keys)):
            for j in range(i+1,len(keys)):
                a,b=memory.items[keys[i]],memory.items[keys[j]]
                score=memory._compat(a.value,b.value)
                if a.subject==b.subject: score=max(score,.55)
                if a.predicate==b.predicate: score=max(score,.45)
                if score>=self.cfg.association_threshold:
                    memory.add_relation(keys[i],keys[j],score,step); created+=1
        return created

class LinearReasoner:
    def __init__(self,cfg): self.cfg=cfg
    def score(self,obs):
        return sum(max(0,min(1,o.strength)) for o in obs)/len(obs) if obs else 0.0

class NonlinearReasoner:
    def __init__(self,cfg): self.cfg=cfg
    def score(self,obs,memory):
        if not obs:return 0.0
        novelty=len({(o.subject,o.predicate) for o in obs})/len(obs)
        return max(0,min(1,memory.strongest_relation()*(.5+.5*novelty)))

class Spiral:
    def __init__(self,cfg): self.cfg=cfg; self.angle=0.0; self.radius=0.0
    def advance(self):
        self.angle+=self.cfg.spiral_turn; self.radius+=self.cfg.spiral_step
        return self.radius*math.cos(self.angle),self.radius*math.sin(self.angle)

class NoiseController:
    def __init__(self,cfg): self.cfg=cfg; self.level=cfg.noise_floor
    def update(self,frustration):
        p=max(0,min(1,frustration/10.0))
        self.level=self.cfg.noise_floor+p*(self.cfg.noise_ceiling-self.cfg.noise_floor)
        return self.level


class _V3RoleFreeDecisionLayer:
    """Experimental graph-based candidate inference connected to DKA's Governor.

    It reads subject/predicate/value/strength only. Observation.role is never used
    to infer candidates or score decisions. Edges are subject -> value; bounded
    paths ending at the current objective create action hypotheses.
    """
    def __init__(self, max_hops=4, min_support=0.05):
        self.max_hops = max_hops
        self.min_support = min_support
        self.outcomes = {}
        self.last_candidates = {}

    @staticmethod
    def _tokens(value):
        import re
        return {x for x in re.split(r'[^a-z0-9]+', str(value).lower().replace('_',' ')) if x}

    def infer(self, observations, objective):
        # First preserve the original graph-edge inference unchanged.
        candidates = {}
        goal = str(objective)
        for o in observations:
            subject, value = str(o.subject), str(o.value)
            if subject == goal or value != goal:
                continue
            try:
                strength = max(0.0, min(1.0, float(o.strength)))
            except (TypeError, ValueError):
                strength = 0.0
            candidates[subject] = max(candidates.get(subject, 0.0), strength)

        # Narrow semantic bridge: map a stated task goal to observed capability
        # descriptors, then gate candidates by explicit availability. No tool is
        # invented and no external selector is called.
        rows = list(observations)
        task_goals = [str(o.value) for o in rows
                      if str(o.subject).lower() in {'task','goal','user'}
                      and str(o.predicate).lower() in {'goal','task_goal','objective','requires'}]
        available = {str(o.value) for o in rows if str(o.predicate).lower() in
                     {'available_resource','available_tool','tool_available'}
                     and str(o.value).lower() not in {'false','no','unavailable','0'}}
        unavailable = {str(o.value) for o in rows if str(o.predicate).lower() in
                       {'unavailable_resource','unavailable_tool'} }
        descriptors = {}
        for o in rows:
            if str(o.predicate).lower() in {'capability','can_do','function'}:
                descriptors.setdefault(str(o.subject), []).append((str(o.value), float(o.strength)))
        ranks = {'very_low':0,'low':1,'medium':2,'high':3,'very_high':4}
        for task_goal in task_goals:
            goal_tokens = self._tokens(task_goal)
            # Common compositional variants: cut_tree ~= cut a tree; move_small_object.
            if 'tree' in goal_tokens and ('cut' in goal_tokens or 'cutting' in goal_tokens):
                goal_tokens |= {'cut','tree','cutting'}
            if 'move' in goal_tokens and 'object' in goal_tokens:
                goal_tokens |= {'move','object','move_object'}
            for tool, caps in descriptors.items():
                if tool in unavailable or (available and tool not in available):
                    continue
                cap_tokens = set().union(*(self._tokens(c) for c,_ in caps))
                overlap = len(goal_tokens & cap_tokens) / max(1, len(goal_tokens))
                # Intentional light synonym bridge for capability phrases.
                goal_norm = ' '.join(sorted(goal_tokens))
                cap_text = ' '.join(c.lower().replace('_',' ') for c,_ in caps)
                if ('cut' in goal_tokens and 'tree' in goal_tokens and
                    any(('cut' in self._tokens(c) and 'tree' in self._tokens(c)) for c,_ in caps)):
                    overlap = max(overlap, 0.95)
                if ('move' in goal_tokens and 'object' in goal_tokens and
                    any('move' in self._tokens(c) and 'object' in self._tokens(c) for c,_ in caps)):
                    overlap = max(overlap, 0.95)
                if overlap < 0.45:
                    continue
                strength = max((w for _,w in caps), default=0.5)
                cost_obs = next((str(o.value).lower() for o in rows
                                 if str(o.subject)==tool and str(o.predicate).lower() in {'cost','cost_level'}), 'medium')
                cost_penalty = 0.035 * ranks.get(cost_obs, 2)
                efficient_bonus = 0.035 if any('efficient' in c.lower() or 'fast' in c.lower() for c,_ in caps) else 0.0
                score = max(0.05, min(0.995, 0.62 + 0.30*min(1.0,overlap) + 0.06*strength + efficient_bonus - cost_penalty))
                candidates[tool] = max(candidates.get(tool, 0.0), score)

        # Contradictory outcome reports are not accepted as success when direct
        # verification says the goal is unmet or the relevant state remains closed.
        false_goal = any(str(o.predicate).lower() in {'goal_met','verified_success'} and
                         str(o.value).lower() in {'false','no','0','failed'} for o in rows)
        closed_state = any(str(o.predicate).lower() in {'door_state','goal_state','task_state'} and
                           str(o.value).lower() in {'closed','blocked','unmet','incomplete','failed'} for o in rows)
        reported_success = any(str(o.predicate).lower() in {'reported_outcome','action_outcome','outcome'} and
                               str(o.value).lower() in {'success','successful','true','1'} for o in rows)
        if (false_goal or closed_state) and reported_success:
            candidates['reject_success'] = 0.995
        # V3 experimental semantic-relation repair: bounded concept + polarity gate.
        # This is explicit and auditable; it is not claimed to be learned semantics.
        concept_lexicon = {
            'fell': ('tree_cut', 1), 'bring down': ('tree_cut', 1), 'cutting': ('tree_cut', 1), 'cut': ('tree_cut', 1), 'timber': ('tree', 0), 'tree': ('tree', 0),
            'unlock': ('door_open', 1), 'release': ('door_open', 1), 'open': ('door_open', 1), 'latch': ('door', 0), 'door': ('door', 0), 'cabinet': ('container', 0), 'drawer': ('container', 0),
            'dry': ('fabric_dry', 1), 'remove moisture': ('fabric_dry', 1), 'moisture': ('moisture', 0), 'clothes': ('fabric', 0), 'fabric': ('fabric', 0), 'soak': ('fabric_dry', -1),
            'cool': ('liquid_cool', 1), 'lower temperature': ('liquid_cool', 1), 'heat': ('liquid_heat', 1), 'heating': ('liquid_heat', 1), 'water': ('liquid', 0), 'liquid': ('liquid', 0), 'temperature': ('temperature', 0),
            'illuminate': ('room_light', 1), 'provide lighting': ('room_light', 1), 'lighting': ('room_light', 1), 'light': ('room_light', 1), 'room': ('room', 0), 'indoors': ('room', 0),
            'lift': ('object_lift', 1), 'raise': ('object_lift', 1), 'crate': ('object', 0), 'box': ('object', 0), 'loaded': ('object', 0), 'object': ('object', 0),
            'move': ('object_move', 1), 'stationary': ('object_move', -1), 'keep object stationary': ('object_move', -1),
            'prevent': ('NEGATION', -1), 'protect': ('NEGATION', -1), 'lock': ('door_open', -1), 'prevent door opening': ('door_open', -1), 'protect tree from cutting': ('tree_cut', -1),
            'translate': ('translate', 1), 'paragraph': ('text', 0), 'measure room temperature': ('temperature_measure', 1),
        }
        def semantic_features(text):
            text = str(text).lower().replace('_', ' ')
            feats = {}
            # Longest phrases first to avoid short tokens overriding compound relations.
            for phrase, (concept, polarity) in sorted(concept_lexicon.items(), key=lambda kv: len(kv[0]), reverse=True):
                if (re.search(r'\b' + re.escape(phrase) + r'\b', text) if ' ' not in phrase else phrase in text):
                    feats[concept] = polarity
            # Explicit negative constructions override positive lexical overlap.
            if any(re.search(r'\b' + p + r'\b', text) for p in ('prevent', 'protect', 'keep', 'stationary', 'soak', 'lock')):
                for concept in list(feats):
                    if concept not in {'NEGATION'} and feats[concept] > 0:
                        feats[concept] = -1
            return feats

        # Only run the semantic gate when a goal and capability are represented
        # by known relation concepts. Unknown goals keep the original conservative path.
        tool_ids = set(descriptors)
        for task_goal in task_goals:
            gf = semantic_features(task_goal)
            goal_positive = {k for k,v in gf.items() if v > 0 and k != 'NEGATION'}
            if not goal_positive:
                continue
            semantic_scores = {}
            recognized_caps = False
            for tool, caps in descriptors.items():
                cf = {}
                for cap_text, _ in caps:
                    cf.update(semantic_features(cap_text))
                if not cf:
                    continue
                recognized_caps = True
                if tool in unavailable or (available and tool not in available):
                    continue
                # A negative relation to the requested effect is a hard exclusion.
                if any(cf.get(concept, 0) < 0 for concept in goal_positive):
                    continue
                matched = goal_positive.intersection(k for k,v in cf.items() if v > 0)
                # Require at least one matching effect concept, not mere shared nouns.
                if not matched:
                    continue
                cost_obs = next((str(o.value).lower() for o in rows
                                 if str(o.subject)==tool and str(o.predicate).lower() in {'cost','cost_level'}), 'medium')
                cost_rank = ranks.get(cost_obs, 2)
                strength = max((w for _,w in caps), default=0.5)
                efficiency_bonus = 0.07 if any(('efficient' in cap.lower() or 'fast' in cap.lower()) for cap,_ in caps) else 0.0
                slow_penalty = 0.03 if any(('slow' in cap.lower() or 'inefficient' in cap.lower()) for cap,_ in caps) else 0.0
                semantic_scores[tool] = 0.72 + 0.06 * (len(matched) / max(1,len(goal_positive))) + 0.04*strength + efficiency_bonus - slow_penalty - 0.035*cost_rank
            # When the relation vocabulary recognizes both goal and capabilities,
            # replace lexical-overlap candidates for those tools with gated scores.
            if recognized_caps:
                for tool in tool_ids:
                    candidates.pop(tool, None)
                candidates.update(semantic_scores)

        self.last_candidates = {k:v for k,v in candidates.items() if v >= self.min_support}
        return dict(self.last_candidates)

    def record_outcome(self, action, success):
        row = self.outcomes.setdefault(str(action), [0, 0])
        row[0] += int(bool(success)); row[1] += 1

    def score(self, action, structural_support):
        success, n = self.outcomes.get(str(action), [0, 0])
        # Neutral prior: feedback matters only after a result is observed.
        empirical = (success + 1.0) / (n + 2.0)
        return 0.70 * structural_support + 0.30 * empirical



class RoleFreeDecisionLayer(_V3RoleFreeDecisionLayer):
    """V4 safety gate: compare action-effect families before accepting V3 scores.

    This is an explicit, bounded ontology—not learned or general language understanding.
    If a goal and a capability both expose recognizable action families, a different
    family is rejected; known opposite directions are hard exclusions. Unknown pairs
    do not gain a candidate from shared nouns alone. Exact structural graph edges remain
    available only when no task-goal/capability comparison is present.
    """
    ACTION_FAMILIES = {
        'cut': ('tree_cut', 1), 'cutting': ('tree_cut', 1), 'fell': ('tree_cut', 1),
        'shatter': ('break', 1), 'break': ('break', 1), 'smash': ('break', 1),
        'mend': ('repair', 1), 'repair': ('repair', 1), 'sew': ('repair', 1), 'fix': ('repair', 1),
        'purge': ('remove', 1), 'remove': ('remove', 1), 'extract': ('remove', 1),
        'inflate': ('pressure_up', 1), 'pump': ('pressure_up', 1),
        'seal': ('contain', 1), 'stop': ('contain', 1), 'prevent': ('contain', 1),
        'copy': ('duplicate', 1), 'duplicate': ('duplicate', 1),
        'weigh': ('measure_mass', 1), 'measure': ('measure', 1), 'determine': ('measure', 1),
        'illuminate': ('light_up', 1), 'brighten': ('light_up', 1), 'light': ('light_up', 1),
        'raise': ('temperature', 1), 'increase': ('increase', 1), 'lower': ('temperature', -1),
        'decrease': ('decrease', 1), 'open': ('open', 1), 'close': ('open', -1),
        'keep': ('maintain', 1), 'drain': ('remove', 1), 'add': ('add', 1),
        'expand': ('size', 1), 'shrink': ('size', -1), 'accelerate': ('speed', 1), 'slow': ('speed', -1),
        'cool': ('temperature', -1), 'heat': ('temperature', 1), 'dry': ('remove_moisture', 1),
        'soak': ('remove_moisture', -1), 'lift': ('elevation', 1), 'move': ('position_change', 1),
        'measure': ('measure', 1), 'paint': ('color', 1), 'encrypt': ('security_transform', 1),
        'count': ('count', 1), 'locate': ('find_location', 1), 'charge': ('charge', 1),
        'sterilize': ('sterilize', 1), 'weigh': ('measure_mass', 1), 'detect': ('detect', 1),
        'restore': ('restore', 1), 'rename': ('rename', 1), 'purify': ('purify', 1),
        'fold': ('fold', 1), 'label': ('label', 1), 'polish': ('polish', 1),
        'unlock': ('open', 1), 'lock': ('open', -1), 'clean': ('clean', 1),
    }
    NEGATORS = {'not', 'never', 'prevent', 'avoid', 'keep', 'without'}

    @classmethod
    def _effect_signature(cls, text):
        toks = [x for x in re.split(r'[^a-z0-9]+', str(text).lower().replace('_',' ')) if x]
        found = [(i, cls.ACTION_FAMILIES[t]) for i,t in enumerate(toks) if t in cls.ACTION_FAMILIES]
        if not found:
            return None
        # Prefer the earliest action token; object words remain separate for overlap checks.
        i, (family, direction) = found[0]
        if any(t in cls.NEGATORS for t in toks[:i]): direction *= -1
        objects = set(toks[i+1:]) - {'a','an','the','to','of','from','into','on','in','with','for','by','and'}
        return family, direction, objects

    def infer(self, observations, objective):
        candidates = super().infer(observations, objective)
        rows = list(observations)
        goals = [str(o.value) for o in rows if str(o.subject).lower() in {'task','goal','user'}
                 and str(o.predicate).lower() in {'goal','task_goal','objective','requires'}]
        descriptors = {}
        for o in rows:
            if str(o.predicate).lower() in {'capability','can_do','function'}:
                descriptors.setdefault(str(o.subject), []).append(str(o.value))
        available = {str(o.value) for o in rows if str(o.predicate).lower() in {'available_resource','available_tool','tool_available'}
                     and str(o.value).lower() not in {'false','no','unavailable','0'}}
        unavailable = {str(o.value) for o in rows if str(o.predicate).lower() in {'unavailable_resource','unavailable_tool'}}
        if goals and descriptors:
            # Remove V3's weak lexical candidates: only candidates passing effect comparison survive.
            for tool in descriptors: candidates.pop(tool, None)
            for goal in goals:
                gs = self._effect_signature(goal)
                if gs is None:
                    continue
                gf, gd, go = gs
                for tool, caps in descriptors.items():
                    if tool in unavailable or (available and tool not in available):
                        continue
                    best = None
                    for cap in caps:
                        cs = self._effect_signature(cap)
                        if cs is None: continue
                        cf, cd, co = cs
                        # Reject different known action families and opposite directions.
                        if gf != cf or gd != cd: continue
                        # If both sides specify object nouns, demand a meaningful intersection.
                        meaningful_g = {x for x in go if x not in {'increase','decrease','up','down','temperature','pressure','room','water','object','tool','thing'}}
                        meaningful_c = {x for x in co if x not in {'increase','decrease','up','down','temperature','pressure','room','water','object','tool','thing'}}
                        if meaningful_g and meaningful_c and not (meaningful_g & meaningful_c):
                            continue
                        best = max(best or 0.0, 0.78 + 0.08 * min(1.0, len(meaningful_g & meaningful_c) / max(1,len(meaningful_g))) )
                    if best is not None:
                        cost = next((str(o.value).lower() for o in rows if str(o.subject)==tool and str(o.predicate).lower() in {'cost','cost_level'}),'medium')
                        rank={'very_low':0,'low':1,'medium':2,'high':3,'very_high':4}.get(cost,2)
                        candidates[tool] = max(candidates.get(tool,0.0), best - .035*rank)
        self.last_candidates = {k:v for k,v in candidates.items() if v >= self.min_support}
        return dict(self.last_candidates)


@dataclass
class GoalHypothesis:
    kind: str
    focus: str
    score: float
    next_action: str
    rationale: str
    evidence: Tuple[str, ...] = ()
    @property
    def objective(self):
        return f"{self.kind}:{self.focus}"

class GoalDiscoveryLayer:
    """Experimental goal induction from content-only academic/context facts.

    It does not read Observation.role or evaluator labels. It generates generic
    goal operators from predicate semantics, graph relations, question signals,
    missing/uncertain knowledge, quantitative givens, and risk evidence. The
    resulting goal is a hypothesis with evidence and confidence, not a hard fact.
    """
    EXPLAIN_SIGNALS = {'asks_why', 'asks_about', 'explain', 'why_question'}
    CALC_SIGNALS = {'asks_for', 'calculate', 'compute', 'solve_for', 'find_value'}
    UNCERTAINTY_SIGNALS = {'unknown', 'missing', 'uncertain', 'contradicts', 'conflicts_with'}
    HARM_WORDS = {'fatal', 'harm', 'injury', 'collision', 'death', 'danger', 'hazard'}

    def __init__(self, switch_margin=0.04, minimum_confidence=0.52):
        self.switch_margin = float(switch_margin)
        self.minimum_confidence = float(minimum_confidence)
        self.active = None
        self.history = []
        self.last_candidates = []
        self.knowledge = {}
        self.hazard_cleared = False

    @staticmethod
    def _norm(x):
        return str(x).strip().lower().replace('-', '_').replace(' ', '_')

    def _ingest(self, observations):
        # Explicit clearance/retraction is a state transition, not another fact to
        # accumulate beside the old danger. Preserve history, but remove active hazard
        # assertions from the working knowledge used for current-goal inference.
        clear_terms = {'cleared', 'ruled_out', 'no_risk', 'no_collision_risk', 'safe',
                       'secured', 'departed', 'resolved', 'false', 'negated', 'not_imminent'}
        active_terms = {'imminent', 'active', 'present', 'approaches', 'on_same_track',
                        'collision_risk', 'dangerous', 'fatal_harm'}
        normalized = []
        for o in observations:
            pred = self._norm(o.predicate); val = self._norm(o.value)
            normalized.append((self._norm(o.subject), pred, val, o))
        clearance = any(val in clear_terms or any(t in val for t in ('no_collision_risk', 'hazard_cleared', 'risk_resolved'))
                        or (pred in {'hazard', 'danger', 'risk_status', 'status'} and val in clear_terms)
                        for _, pred, val, _ in normalized)
        fresh_danger = any((pred in {'hazard', 'danger', 'imminent', 'collision_risk'} and val in active_terms)
                           or (pred in {'approaches', 'near', 'on_same_track'} and not any(t in val for t in ('safe','safely','departed','cleared')) and any(t in f'{sub}_{val}' for t in ('train','collision','railway','track')))
                           for sub, pred, val, _ in normalized)
        if clearance and not fresh_danger:
            self.hazard_cleared = True
            if self.active is not None and self.active.kind == 'prevent_harm':
                self.active = None
            self.knowledge = {k:v for k,v in self.knowledge.items()
                              if not (k[0] in {'hazard','danger','collision_risk'} or k[1] in {'hazard','danger','imminent','collision_risk'}
                                      or (k[1] in {'approaches','near','on_same_track'} and any(t in '_'.join(k) for t in ('train','collision','railway','track')))
                                      or any(t in '_'.join(k) for t in ('fatal_harm','collision_risk','imminent_harm')))}
        if fresh_danger:
            self.hazard_cleared = False
        for sub, pred, val, o in normalized:
            # Negated/retracted hazards are not positive evidence for a danger goal.
            if (sub in {'hazard','danger','collision_risk'} or pred in {'hazard','danger','imminent','collision_risk','risk_status'}) and (val in clear_terms or val.startswith('no_')):
                continue
            key = (sub, pred, val)
            try: strength = max(0.0, min(1.0, float(o.strength)))
            except (TypeError, ValueError): strength = 0.5
            old = self.knowledge.get(key, 0.0)
            self.knowledge[key] = max(old, strength)
        # Bound accumulated context; preserve strongest evidence only.
        if len(self.knowledge) > 2000:
            self.knowledge = dict(sorted(self.knowledge.items(), key=lambda kv: kv[1], reverse=True)[:1500])

    @staticmethod
    def _tokens(text):
        return {t for t in re.split(r"[^a-z0-9]+", str(text).lower()) if t}

    def infer(self, observations):
        """Infer goal operators compositionally from predicate/argument structure.

        V3 deliberately treats predicates as tokenized relations rather than requiring
        exact predicate-name matches. This remains a symbolic experimental parser,
        not a claim of unrestricted natural-language understanding.
        """
        self._ingest(observations)
        triples = list(self.knowledge.items())
        proposals = {}
        def add(kind, focus, score, action, rationale, evidence=()):
            focus = self._norm(focus) or 'unspecified'
            score = max(0.0, min(.999, float(score)))
            key = (kind, focus)
            cand = GoalHypothesis(kind, focus, score, action, rationale, tuple(evidence))
            if key not in proposals or proposals[key].score < score:
                proposals[key] = cand

        clear_tokens = {'cleared','ruled_out','safe','safely','secured','departed','resolved','negated','false'}
        safe_context_tokens = {'safe','safely','secured','departed','cleared','resolved'}
        harm_tokens = {'fatal','injury','harm','death','collision','danger','hazard','unsafe'}
        risk_rows=[]
        explain_rows=[]
        calc_rows=[]
        gap_rows=[]
        relation_rows=[]
        quantity_rows=[]
        for (sub,pred,val), strength in triples:
            st, pt, vt = self._tokens(sub), self._tokens(pred), self._tokens(val)
            joined = st | pt | vt
            full = f'{sub}_{pred}_{val}'
            if vt & clear_tokens or val.startswith('no_') or 'no_collision_risk' in val:
                continue
            # Risk is compositional: proximity/approach + an agent/object, or a
            # causal consequence relation to an explicit harm concept.
            proximity = bool(pt & {'approaches','approach','near','closing','distance','proximity','approaching'})
            if proximity and (vt & safe_context_tokens):
                proximity = False
            causal = bool(pt & {'cause','causes','result','results','lead','leads','produce','produces'})
            explicit_harm = bool(vt & harm_tokens) or bool(joined & {'fatal','injury','collision','hazard','danger'})
            risk_marker = bool(joined & {'train','railway','track','robot','vehicle','collision','hazard','danger'})
            if (proximity and risk_marker) or (causal and explicit_harm):
                risk_rows.append((sub,pred,val,strength,full,proximity and risk_marker))

            # Goal-type inference uses relation semantics and argument roles.
            if (pt & {'why','reason','explain','explanation','cause','causes','mechanism'}) and (pt & {'seek','seeks','ask','asks','request','requests','question','reason','explanation'}):
                explain_rows.append((sub,val,strength,full))
            elif pt & {'asks_why','asks_about','why_question','explain'}:
                explain_rows.append((sub,val,strength,full))
            if (pt & {'numeric','number','calculate','calculation','compute','computing','solve','value','quantity'}) and (pt & {'request','requests','output','find','calculate','compute','solve','asks','ask'}):
                calc_rows.append((sub,val,strength,full))
            elif pred in self.CALC_SIGNALS:
                calc_rows.append((sub,val,strength,full))
            if (pt & {'lack','lacks','missing','unknown','uncertain','uncertainty','contradict','contradicts','conflict','conflicts'}) and (pt & {'information','knowledge','data','evidence','boundary','coefficient','about','missing','unknown','uncertain','contradicts','conflicts_with'}):
                gap_rows.append((sub,val,strength,full))
            elif pred in self.UNCERTAINTY_SIGNALS:
                gap_rows.append((sub,val,strength,full))
            if pred not in {'state','status','measurement','formula','value','given','quantity'} and not (vt & clear_tokens):
                relation_rows.append((sub,pred,val,strength,full))
            if (pred in {'measurement','formula','value','given','quantity','equals','means','requires'}
                or bool(vt & {'cm','mm','meter','meters','kg','g','minutes','seconds','pi'} )
                or any(ch.isdigit() for ch in val)):
                quantity_rows.append((sub,pred,val,strength,full))

        # Strong, current risk overrides ordinary objectives. Cleared/negated rows
        # are excluded above, so a clearance-only context does not create danger.
        if risk_rows:
            risk_strength=max(x[3] for x in risk_rows)
            imminent=any(x[5] for x in risk_rows)
            add('prevent_harm','imminent_harm' if imminent else 'harm_risk',
                min(.999,.74+.20*risk_strength+(.05 if imminent else 0)), 'SAFETY',
                'composed proximity/causal evidence indicates possible harm',
                [x[4] for x in risk_rows[:8]])

        for sub,val,strength,full in explain_rows:
            focus = val if val not in {'true','yes','why','reason'} else sub
            add('explain',focus,.68+.20*strength,f'investigate_relation:{focus}',
                'reason/explanation intent inferred from relation tokens',[full])

        for sub,val,strength,full in calc_rows:
            focus=val if val not in {'true','yes','output','numeric_output','value'} else sub
            related=[q for q in quantity_rows if focus in q[0] or focus in q[2] or q[0] in {sub,'radius','height','length','width','mass','time'}]
            # A stated formula plus measurements is quantitative evidence even if
            # predicates do not use the old 'value/equals/given' vocabulary.
            has_formula=any('formula' in q[1] or 'formula' in q[4] for q in relation_rows+[(a,b,c,d,e) for a,b,c,d,e in quantity_rows])
            if related or has_formula or quantity_rows:
                add('calculate',focus,min(.985,.76+.18*strength+.015*min(4,len(related))),
                    f'execute_calculation:{focus}','numeric intent combined with quantities/formula evidence',[full]+[q[4] for q in related[:5]])
            else:
                add('answer_question',focus,.55+.18*strength,f'investigate:{focus}',
                    'numeric intent detected but quantitative evidence is incomplete',[full])

        for sub,val,strength,full in gap_rows:
            focus = f'{sub}_{val}' if val not in {'true','yes','unknown','missing','uncertain'} else sub
            add('resolve_uncertainty',focus,.60+.28*strength,f'check_evidence:{focus}',
                'information deficit/conflict inferred from relation semantics',[full])

        # Generic relation understanding applies to unfamiliar predicates too,
        # while avoiding status-only/clearance-only inputs.
        if not proposals and relation_rows:
            s0,p0,v0,w0,full=max(relation_rows,key=lambda row:row[3])
            add('understand_relation',full,.53+.20*w0,f'investigate_relation:{full}',
                'no explicit task intent; infer a goal to understand a supplied relation',[full])

        candidates=sorted(proposals.values(),key=lambda g:g.score,reverse=True)
        self.last_candidates=candidates
        if not candidates or candidates[0].score < self.minimum_confidence:
            self.history.append({'selected':None,'reason':'insufficient_goal_evidence','candidate_count':len(candidates)})
            return None
        # In an unresolved tie, prefer a safety goal; otherwise require a clear
        # margin between different goal kinds rather than silently oscillating.
        best=candidates[0]
        if len(candidates)>1 and candidates[1].kind != best.kind and best.kind!='prevent_harm':
            if best.score-candidates[1].score < self.switch_margin:
                self.history.append({'selected':None,'reason':'competing_goals_ambiguous','candidate_count':len(candidates)})
                return None
        if self.active is not None and self.active.objective != best.objective:
            if best.kind != 'prevent_harm' and best.score < self.active.score + self.switch_margin:
                best=self.active
        changed=self.active is None or self.active.objective != best.objective
        self.active=best
        self.history.append({'selected':best.objective,'kind':best.kind,'focus':best.focus,
                             'score':best.score,'changed':changed,'rationale':best.rationale})
        return best

class Governor:
    """Primary objective holder; AAA informs it but does not replace it."""
    def __init__(self,cfg):
        self.cfg=cfg; self.primary_objective='explore'; self.objective_explicit=False; self.current_target='environment'
        self.frustration=0.0; self.directive_history=[]
        self.pre_safety_target=None; self.safety_active=False
    def set_objective(self,objective):
        self.primary_objective=objective
        self.objective_explicit=True
        if not self.directive_history and self.current_target=='environment': self.current_target=objective
    def update_frustration(self,progress):
        self.frustration=max(0,self.frustration-progress*2) if progress>.05 else self.frustration+1
    def risk_fusion(self, observations):
        danger=0.0; p_failure=0.0; failure_cost=0.0; irreversible=False
        for o in observations:
            pred=str(o.predicate).lower().replace('-','_').strip()
            val=str(o.value).lower().strip()
            cleared = val in {'cleared','ruled_out','no_risk','no_collision_risk','safe','secured','departed','resolved','false','negated','not_imminent'} or val.startswith('no_')
            if pred in {'danger','imminent','hazard','collision_risk'} and not cleared:
                danger=max(danger,max(0.0,min(1.0,float(o.strength))))
            if pred in {'failure_probability','failure_prob','p_failure'}:
                try: p_failure=max(p_failure,max(0.0,min(1.0,float(o.value))))
                except (TypeError,ValueError): pass
            if pred in {'failure_cost','cost_of_failure','damage_cost'}:
                try: failure_cost=max(failure_cost,max(0.0,float(o.value)))
                except (TypeError,ValueError): pass
            if pred in {'unrecoverable','irreversible'} or val in {'unrecoverable','irreversible','fatal','permanent'}:
                irreversible=True
        expected_loss=p_failure*failure_cost
        loss_score=1.0-math.exp(-expected_loss) if expected_loss>0 else 0.0
        if irreversible: loss_score=max(loss_score,danger)
        trigger=(danger>=self.cfg.danger_cost_threshold or
                 loss_score>=self.cfg.expected_loss_trigger or
                 (irreversible and danger>=self.cfg.irreversible_danger_floor))
        return {'danger':danger,'p_failure':p_failure,'failure_cost':failure_cost,
                'expected_loss':expected_loss,'loss_score':loss_score,
                'irreversible':irreversible,'trigger':trigger}
    def decide(self,step,linear_score,nonlinear_score,memory,audit_score,observations=(),audit_result=None,learned_utilities=None,transfer_blocked=False,role_free_candidates=None,role_free_layer=None):
        audit_result = audit_result or {"contradictions": 0.0, "conflicts": []}
        learned_utilities = learned_utilities or {}
        risk=self.risk_fusion(observations)
        if risk['trigger']:
            if not self.safety_active:
                self.pre_safety_target=self.current_target
            self.safety_active=True
            self.frustration=max(self.frustration,risk['danger']*self.cfg.danger_priority_gain)
            d=Directive('SAFETY','SAFETY',min(1.0,max(risk['danger'],risk['loss_score'])),
                f"risk_fusion; danger={risk['danger']:.3f}; expected_loss={risk['expected_loss']:.3f}; irreversible={risk['irreversible']}",step)
            self.current_target='SAFETY'; self.directive_history.append(d); return d
        if self.safety_active:
            # Safety is a temporary override. On clearance, restore the pre-hazard target
            # and bypass stale hazard-derived associations for this recovery decision.
            target=self.pre_safety_target or 'environment'
            self.current_target=target; self.safety_active=False; self.pre_safety_target=None
            d=Directive(target,self.primary_objective,1.0,'safety_cleared; restore_pre_safety_target',step)
            self.directive_history.append(d); return d
        # Causal contradiction routing: when the pre-update audit finds a conflict,
        # do not silently continue with ordinary target selection. Request reassessment
        # and preserve the conflicting values in the decision trace for review.
        conflicts=audit_result.get("conflicts", [])
        if conflicts:
            strongest=max((float(c.get("strength",0.0)) for c in conflicts),default=0.0)
            priority=min(1.0,0.35+0.40*strongest+0.05*max(0,len(conflicts)-1))
            detail="; ".join(
                f"{c.get('key')}: {c.get('old_value')!r} -> {c.get('new_value')!r}"
                for c in conflicts[:3]
            )
            d=Directive('REASSESS',self.primary_objective,priority,
                        f'pre_update_contradiction; count={len(conflicts)}; {detail}',step)
            self.current_target='REASSESS'; self.directive_history.append(d); return d
        combined=self.cfg.linear_weight*linear_score+self.cfg.nonlinear_weight*nonlinear_score
        # Integrated role-free route: candidate hypotheses come from graph structure,
        # not Observation.role or MemoryItem.role. Safety and contradiction guards above
        # remain in force.
        role_free_candidates = role_free_candidates or {}
        candidates=[]
        for action, structural_support in role_free_candidates.items():
            learned = 0.0 if transfer_blocked else float(learned_utilities.get(action, 0.0))
            if role_free_layer is not None:
                score = role_free_layer.score(action, structural_support)
            else:
                score = 0.70 * structural_support + 0.30 * learned
            if not transfer_blocked and learned > 0.0:
                score = 0.80 * score + 0.20 * learned
            candidates.append((action, score, (action, 'role_free'), structural_support, structural_support))
        if candidates:
            target,score,_,_,_=max(candidates,key=lambda x:x[1])
            priority=max(0,min(1,.55*min(1.0,score)+.45*combined))
        else:
            # Explicit fail-closed behavior: no currently supported candidate means
            # no action recommendation. Keep the objective as internal recovery anchor,
            # but do not present it as an evidence-backed decision.
            self.current_target=self.primary_objective
            d=Directive('NO_DECISION',self.primary_objective,0.0,
                        f'insufficient_current_evidence; request_new_search; combined={combined:.4f}; audit={audit_score:.4f}',step)
            self.directive_history.append(d)
            return d
        d=Directive(target,self.primary_objective,priority,
                    f'primary={self.primary_objective}; combined={combined:.4f}; audit={audit_score:.4f}',step)
        self.current_target=target; self.directive_history.append(d); return d

class ReferenceEngine:
    VERSION=REFERENCE_ENGINE_VERSION; ARCHITECTURE=ARCHITECTURE_ID
    def __init__(self,config=None):
        self.cfg=config or ReferenceConfig(); self._rng=random.Random(self.cfg.seed)
        self.memory=ReferenceMemory(self.cfg); self.aaa=AAA(self.cfg)
        self.linear=LinearReasoner(self.cfg); self.nonlinear=NonlinearReasoner(self.cfg)
        self.spiral=Spiral(self.cfg); self.noise=NoiseController(self.cfg); self.governor=Governor(self.cfg)
        self.role_free_layer = RoleFreeDecisionLayer()
        self.goal_discovery = GoalDiscoveryLayer()
        self.trace=[]
    def config_hash(self):
        return hashlib.sha256(json.dumps(asdict(self.cfg),sort_keys=True).encode()).hexdigest()[:16]
    def source_sha256(self):
        # Independent implementation identity; intentionally separate from the
        # historical architecture/config fingerprint to preserve comparability.
        try:
            source=pathlib.Path(__file__).read_bytes()
        except OSError:
            source=type(self).__name__.encode()
        return hashlib.sha256(source).hexdigest()
    def fingerprint(self):
        payload={"version":self.VERSION,"architecture":self.ARCHITECTURE,
                 "config":asdict(self.cfg),"components":[type(self.memory).__name__,type(self.aaa).__name__,
                 type(self.linear).__name__,type(self.nonlinear).__name__,type(self.spiral).__name__,
                 type(self.noise).__name__,type(self.governor).__name__,type(self.role_free_layer).__name__,type(self.goal_discovery).__name__],
                 "experimental_branch": EXPERIMENTAL_BRANCH_ID}
        return hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
    def record_action_outcome(self, action, success):
        """Feed an observed environment outcome into the role-free decision layer."""
        self.role_free_layer.record_outcome(action, success)

    def step(self,observations,step):
        # Accept role-free objects and deliberately discard any supplied role label.
        normalized=[]
        for o in observations or []:
            normalized.append(Observation(subject=str(o.subject), predicate=str(o.predicate),
                value=o.value, strength=getattr(o,'strength',1.0), source=getattr(o,'source','environment'),
                timestamp=getattr(o,'timestamp',step), role='evidence'))
        observations=normalized
        # Environment feedback can be delivered as an ordinary fact; it updates the
        # reusable action-outcome history before the next decision is scored.
        for o in observations:
            pred = str(o.predicate).strip().lower().replace('-', '_')
            label = str(o.value).strip().lower()
            if pred in {'action_outcome', 'outcome'} and label in {'success', 'successful', 'true', '1', 'failure', 'failed', 'false', '0'}:
                self.role_free_layer.record_outcome(o.subject, label in {'success', 'successful', 'true', '1'})
        # Infer/revise the objective from raw knowledge and context before selecting the next action.
        # No objective label, role label, or evaluator answer is supplied to this layer.
        goal_hypothesis = self.goal_discovery.infer(observations)
        if goal_hypothesis is not None and (not self.governor.objective_explicit or goal_hypothesis.kind == 'prevent_harm'):
            self.governor.primary_objective = goal_hypothesis.objective
            # Route an inferred high-confidence harm-prevention goal into the existing
            # safety gate as evidence, without changing the frozen reference engine.
            if goal_hypothesis.kind == 'prevent_harm':
                observations.append(Observation(subject='goal_discovery', predicate='hazard',
                    value='imminent', strength=goal_hypothesis.score, source='inferred_goal',
                    timestamp=step, role='evidence'))
        # Infer action hypotheses from the newly inferred objective.
        role_free_candidates = self.role_free_layer.infer(observations, self.governor.primary_objective)
        # Goal hypothesis proposes a next investigative step; the goal and action remain distinct.
        if goal_hypothesis is not None and goal_hypothesis.kind != 'prevent_harm':
            role_free_candidates.setdefault(goal_hypothesis.next_action, goal_hypothesis.score)
        # Causal ordering repair: measure novelty and contradictions against the
        # pre-update memory snapshot, otherwise observe() erases those signals.
        analysis=self.aaa.analysis(observations,self.memory)
        audit=self.aaa.audit(observations,self.memory)
        # Experimental causal-link repair: pair delayed outcome feedback with
        # the feature already stored for the same example, before updating items.
        for o in observations:
            if str(o.predicate).lower() == 'outcome':
                self.memory.record_feedback(o.subject, o.value)
        # Same-step pairing: record both exact-feature statistics and reusable
        # abstract-mechanism statistics from the feedback attached to the same example.
        current_features = {o.subject: o.value for o in observations if str(o.predicate).lower() == 'feature'}
        current_mechanisms = {o.subject: o.value for o in observations if str(o.predicate).lower() in {'mechanism','relation_descriptor'}}
        for o in observations:
            if str(o.predicate).lower() == 'outcome':
                label = str(o.value).strip().lower()
                if label in {'success', 'failure'} and o.subject in current_features:
                    feature = str(current_features[o.subject])
                    row = self.memory.feedback_stats.setdefault(feature, {'success': 0.0, 'failure': 0.0, 'n': 0.0})
                    row[label] += 1.0; row['n'] += 1.0
                if label in {'success', 'failure'} and o.subject in current_mechanisms:
                    mechanism = str(current_mechanisms[o.subject])
                    self.memory.record_mechanism_feedback(mechanism, label)
        for o in observations:
            self.memory.observe(o,step)
        self.aaa.association(observations,self.memory,step)
        reassessed=self.memory.reassess_relations(step)
        linear=self.linear.score(observations); nonlinear=self.nonlinear.score(observations,self.memory)
        progress=max(0,.5*analysis['coherence']+.5*self.memory.strongest_relation())
        self.governor.update_frustration(progress); noise=self.noise.update(self.governor.frustration)
        lam=self.memory.dynamic_forgetting(step,self.governor.frustration); self.spiral.advance()
        # Risk Fusion is part of Governor decision fusion; safety override is temporary.
        risk=self.governor.risk_fusion(observations)
        if risk['trigger']:
            self.governor.frustration=max(self.governor.frustration,risk['danger']*self.cfg.danger_priority_gain)
        # Experimental cross-domain route: estimate success rate from prior outcomes
        # for each candidate's observed mechanism descriptor, then pass that estimate
        # into Governor decision fusion. Explicit local counterevidence can block transfer.
        mechanisms_by_subject = {o.subject: str(o.value) for o in observations
                                 if str(o.predicate).lower() in {'mechanism','relation_descriptor'}}
        learned_utilities = {}
        for subject, mechanism in mechanisms_by_subject.items():
            row = self.memory.mechanism_feedback_stats.get(mechanism)
            if row and row.get('n',0.0) >= 4:
                learned_utilities[subject] = (row.get('success',0.0)+1.0)/(row.get('n',0.0)+2.0)
        transfer_blocked = any(str(o.predicate).lower() == 'transfer_block' and
                               str(o.value).strip().lower() in {'true','yes','blocked','1'}
                               for o in observations)
        d=self.governor.decide(step,linear,nonlinear,self.memory,audit['audit_score'],observations,audit,
                              learned_utilities=learned_utilities,transfer_blocked=transfer_blocked,
                              role_free_candidates=role_free_candidates,role_free_layer=self.role_free_layer)
        self.trace.append(StepRecord(step,len(observations),len(self.memory.items),len(self.memory.relations),
                                     self.memory.strongest_relation(),noise,lam,linear,nonlinear,
                                     d.target,d.objective,reassessed,int(audit['contradictions'])))
        return d
    def run(self,scenario):
        self.governor.set_objective(scenario.objective)
        for step in range(self.cfg.max_steps):
            obs=scenario.observations(step)
            if obs is None: break
            self.step(obs,step)
            if scenario.stop(self,step): break
        return RunResult(self.VERSION,self.ARCHITECTURE,self.cfg.seed,scenario.name,self.config_hash(),
                         self.trace,self.governor.directive_history[-1] if self.governor.directive_history else None,
                         scenario.success(self),scenario.metrics(self),scenario.notes)

class Scenario:
    name='abstract'; objective='explore'; notes=[]
    def observations(self,step): raise NotImplementedError
    def stop(self,engine,step): return step>=20
    def success(self,engine): return False
    def metrics(self,engine): return {'steps':float(len(engine.trace)),'memory_size':float(len(engine.memory.items)),
                                      'relations':float(len(engine.memory.relations)),'max_relation':engine.memory.strongest_relation()}

class ReturnOfBScenario(Scenario):
    name='fingerprint_return_of_B'; objective='energy'; notes=['B is never explicitly labelled correct.']
    def observations(self,s):
        if s==0:return [Observation('energy','source','chemical',1,role='evidence'),Observation('A','linked_to','energy',.9,role='candidate')]
        if s==1:return [Observation('B','linked_to','unknown',.6,role='candidate')]
        if s in (2,3):return [Observation('B','linked_to','energy',.95,role='candidate'),Observation('bioelectric','related_to','energy',.9,role='evidence')]
        if s>=4:return [Observation('B','linked_to','energy',.98,role='candidate')]
        return None
    def stop(self,e,s): return s>=6
    def success(self,e): return e.governor.current_target=='B' and len(e.memory.relations)>0
    def metrics(self,e):
        m=super().metrics(e); b=e.memory.items.get(('B','linked_to')); m['B_confidence']=b.confidence if b else 0; m['B_selected']=float(e.governor.current_target=='B'); return m

class InversionScenario(Scenario):
    name='forced_inversion'; objective='energy'; notes=['Misleading route starts stronger; later evidence changes the landscape.']
    def observations(self,s):
        if s==0:return [Observation('energy','source','X',1,role='evidence'),Observation('wrong','route','energy',1,role='candidate'),Observation('right','route','noise',.2,role='candidate')]
        if s in (1,2):return [Observation('wrong','route','energy',1,role='candidate')]
        if s in (3,4,5):return [Observation('right','route','energy',1,role='candidate'),Observation('bio','process','energy',1,role='evidence')]
        return None
    def stop(self,e,s): return s>=7
    def success(self,e): return e.governor.current_target=='right'
    def metrics(self,e):
        m=super().metrics(e); m['final_target_right']=float(e.governor.current_target=='right'); return m

class DynamicForgettingScenario(Scenario):
    name='dynamic_forgetting'; objective='target'; notes=['Tests time-varying retention without changing the engine.']
    def observations(self,s):
        if s<3:return [Observation('old_path','supports','target',1)]
        if s<9:return [Observation('new_path','supports','target',.95)]
        if s in (9,10):return [Observation('new_path','supports','target',1),Observation('old_path','supports','closed',.05)]
        return None
    def stop(self,e,s): return s>=12
    def success(self,e):
        old=e.memory.items.get(('old_path','supports')); new=e.memory.items.get(('new_path','supports'))
        return bool(new and (not old or new.confidence>=old.confidence))
    def metrics(self,e):
        m=super().metrics(e); old=e.memory.items.get(('old_path','supports')); new=e.memory.items.get(('new_path','supports'))
        m['old_confidence']=old.confidence if old else 0; m['new_confidence']=new.confidence if new else 0; return m

class CrossDomainAssociationScenario(Scenario):
    name='cross_domain_AAA'; objective='energy'; notes=['Governor retains the primary objective while AAA builds cross-domain relations.']
    def observations(self,s):
        if s==0:return [Observation('energy','domain','chemical',1),Observation('reaction','produces','energy',.9)]
        if s==1:return [Observation('glow','domain','biological',.8),Observation('glow','contains','electrical',.9)]
        if s==2:return [Observation('bioelectric','domain','electrical',1),Observation('bioelectric','related','energy',1)]
        if s>=3:return [Observation('bioelectric','related','energy',1)]
        return None
    def stop(self,e,s): return s>=6
    def success(self,e): return len(e.memory.relations)>=2
    def metrics(self,e):
        m=super().metrics(e); m['cross_domain_relations']=float(len(e.memory.relations));
        m['objective_preserved']=float(all(d.objective==self.objective for d in e.governor.directive_history)); return m

def run_same_engine(scenarios,config=None):
    results=[]
    for scenario in scenarios:
        results.append(ReferenceEngine(config).run(scenario))
    return results

def reference_suite(config=None):
    scenarios=[ReturnOfBScenario(),InversionScenario(),DynamicForgettingScenario(),CrossDomainAssociationScenario()]
    results=run_same_engine(scenarios,config)
    ids={(r.engine_version,r.architecture_id,r.config_hash) for r in results}
    assert len(ids)==1,'REFERENCE VIOLATION: different engine/config detected.'
    return results

def self_test():
    cfg=ReferenceConfig(); e=ReferenceEngine(cfg)
    expected={'ReferenceMemory','AAA','LinearReasoner','NonlinearReasoner','Spiral','NoiseController','Governor'}
    actual={type(e.memory).__name__,type(e.aaa).__name__,type(e.linear).__name__,type(e.nonlinear).__name__,
            type(e.spiral).__name__,type(e.noise).__name__,type(e.governor).__name__}
    assert actual==expected and e.VERSION==REFERENCE_ENGINE_VERSION and e.ARCHITECTURE==ARCHITECTURE_ID
    results=reference_suite(cfg); assert len({r.config_hash for r in results})==1
    return {'status':'PASS','engine_version':e.VERSION,'architecture_id':e.ARCHITECTURE,
            'config_hash':e.config_hash(),'fingerprint':e.fingerprint(),
            'success_flags':{r.scenario:r.success for r in results}}

if __name__=='__main__':
    print(json.dumps(self_test(),ensure_ascii=False,indent=2))
    print('\nREFERENCE SUITE')
    for r in reference_suite():
        print(json.dumps({'scenario':r.scenario,'success':r.success,'metrics':r.metrics,
                          'engine':r.engine_version,'architecture':r.architecture_id,
                          'config_hash':r.config_hash},ensure_ascii=False))

class CausalSearchExecutor:
    """Experimental outer-loop repair with a fail-closed evidence gate.

    The reference engine remains unchanged. Search results are not allowed to
    trigger a decision merely because a candidate has a high confidence score:
    at least two explicitly named, distinct evidence sources must support the
    current objective, and the result set must not contain explicit opposition.
    This is a conservative minimum gate, not a general truth detector.
    """
    OPPOSITION_PREDICATES = {'contradicts', 'opposes', 'disproves', 'unsafe', 'danger'}
    OPPOSITION_VALUES = {'false', 'unsafe', 'danger', 'reject', 'contradicted', 'unsupported'}

    def __init__(self, engine, search_provider, max_searches=2, min_independent_sources=2):
        self.engine = engine
        self.search_provider = search_provider
        self.max_searches = max(0, int(max_searches))
        self.min_independent_sources = max(2, int(min_independent_sources))
        self.search_log = []

    def _validate_search_results(self, observations):
        """Return (accepted, reason, independent_sources) for provider results."""
        objective = str(self.engine.governor.primary_objective).strip().lower()
        evidence = list(observations)  # role-free: every returned fact is audited by content
        oppositions = []
        supporting_sources = set()
        for obs in evidence:
            predicate = str(obs.predicate).strip().lower().replace('-', '_')
            value = str(obs.value).strip().lower()
            if predicate in self.OPPOSITION_PREDICATES or value in self.OPPOSITION_VALUES:
                oppositions.append(obs)
            # Require explicit objective-aligned support and a named source.
            if predicate in {'supports', 'validates', 'corroborates', 'confirms'} and value == objective:
                source = str(obs.source).strip()
                if source and source.lower() not in {'', 'environment', 'unknown', 'none'}:
                    supporting_sources.add(source)
        if oppositions:
            return False, 'explicit_opposing_evidence', sorted(supporting_sources)
        if len(supporting_sources) < self.min_independent_sources:
            return False, 'insufficient_independent_objective_support', sorted(supporting_sources)
        if not any(str(o.subject).strip() != objective and str(o.value).strip().lower() == objective
                   for o in observations):
            return False, 'no_structurally_inferred_action_in_search_results', sorted(supporting_sources)
        return True, 'minimum_evidence_gate_passed', sorted(supporting_sources)

    def run_cycle(self, initial_observations, start_step=0):
        step = int(start_step)
        directive = self.engine.step(list(initial_observations or []), step)
        step += 1
        searches = 0
        while directive.target in {'REASSESS', 'NO_DECISION'} and searches < self.max_searches:
            request = {
                'objective': self.engine.governor.primary_objective,
                'directive': directive.target,
                'reason': directive.reason,
                'attempt': searches + 1,
            }
            try:
                found = list(self.search_provider(request) or [])
            except Exception as exc:
                self.search_log.append({'request': request, 'status': 'provider_error',
                                        'error': type(exc).__name__})
                directive = Directive('NO_DECISION', self.engine.governor.primary_objective, 0.0,
                                      'search_provider_error; fail_closed', step)
                break
            searches += 1
            if not found:
                self.search_log.append({'request': request, 'status': 'empty', 'count': 0})
                directive = Directive('NO_DECISION', self.engine.governor.primary_objective, 0.0,
                                      'empty_search_results; fail_closed', step)
                break
            accepted, reason, sources = self._validate_search_results(found)
            self.search_log.append({'request': request,
                                    'status': 'accepted' if accepted else 'rejected',
                                    'count': len(found), 'validation': reason,
                                    'independent_sources': sources})
            if not accepted:
                directive = Directive('NO_DECISION', self.engine.governor.primary_objective, 0.0,
                                      f'search_evidence_rejected; {reason}', step)
                break
            directive = self.engine.step(found, step)
            step += 1
            # Safety override is final for this cycle; never search around it.
            if directive.target == 'SAFETY':
                break
        return {
            'directive': directive,
            'searches': searches,
            'search_log': list(self.search_log),
            'resolved': directive.target not in {'REASSESS', 'NO_DECISION'},
            'steps_used': step - int(start_step),
        }


def causal_executor_repair_test():
    # 1) A contradiction must cause reassessment, then provider-supplied fresh
    # evidence must pass through the same engine and yield an evidence-backed target.
    cfg = ReferenceConfig(seed=4107)
    engine = ReferenceEngine(cfg)
    engine.governor.set_objective('energy')
    initial = [Observation('source','quality','safe',0.9,role='evidence'),
               Observation('route_A','supports','safe',0.9,role='candidate')]
    # Seed an existing value so the first update creates a genuine audit conflict.
    engine.memory.observe(Observation('sensor','state','safe',0.9,role='evidence'), 0)
    conflict_input = initial + [Observation('sensor','state','danger',0.99,role='evidence')]
    calls = []
    def provider(req):
        calls.append(req)
        return [Observation('route_B','supports','energy',0.99,role='candidate'),
                Observation('independent_source','supports','energy',0.98,source='source_A',role='evidence'),
                Observation('second_independent_source','supports','energy',0.96,source='source_B',role='evidence')]
    result = CausalSearchExecutor(engine, provider, max_searches=2).run_cycle(conflict_input, 1)
    assert calls, 'search provider was not called after reassessment'
    assert result['searches'] >= 1
    assert result['directive'].target == 'route_B', result['directive']

    # 2) Empty provider results must terminate safely, with no fabricated decision.
    engine2 = ReferenceEngine(ReferenceConfig(seed=4108))
    engine2.governor.set_objective('energy')
    empty = CausalSearchExecutor(engine2, lambda req: [], max_searches=2)
    result2 = empty.run_cycle([], 0)
    assert result2['directive'].target == 'NO_DECISION'
    assert result2['searches'] == 1
    assert not result2['resolved']

    # 3) Safety always wins; executor must not call search after a safety directive.
    engine3 = ReferenceEngine(ReferenceConfig(seed=4109))
    engine3.governor.set_objective('energy')
    safety_calls = []
    def unsafe_provider(req):
        safety_calls.append(req)
        return [Observation('route_B','supports','energy',1,role='candidate')]
    safe_result = CausalSearchExecutor(engine3, unsafe_provider, max_searches=2).run_cycle(
        [Observation('track','danger',1.0,0.99,role='evidence')], 0)
    assert safe_result['directive'].target == 'SAFETY'
    assert safe_result['searches'] == 0 and not safety_calls

    return {'status':'PASS', 'checks':3,
            'contradiction_to_search_to_decision':result['directive'].target,
            'empty_search_fail_closed':result2['directive'].target,
            'safety_precedence':safe_result['directive'].target,
            'reference_fingerprint':ReferenceEngine(ReferenceConfig()).fingerprint(),
            'note':'Experimental wrapper only; does not prove real-world retrieval quality or task-success improvement.'}

if __name__ == '__main__':
    print('\nCAUSAL SEARCH EXECUTOR REPAIR')
    print(json.dumps(causal_executor_repair_test(), ensure_ascii=False, indent=2))


def role_free_integration_tests():
    results = {}
    # Raw objects without a role field must pass through the integrated DKA pipeline.
    from types import SimpleNamespace
    raw = [SimpleNamespace(subject='route_A', predicate='supports', value='goal', strength=.9, source='s1'),
           SimpleNamespace(subject='sensor_1', predicate='points_to', value='route_A', strength=.8, source='s2')]
    e = ReferenceEngine(ReferenceConfig(seed=20261016, max_steps=10))
    e.governor.set_objective('goal')
    try:
        d = e.step(raw, 0)
        results['raw_input_without_role'] = d.target == 'route_A'
    except Exception as exc:
        results['raw_input_without_role'] = False
        results['raw_input_error'] = type(exc).__name__ + ': ' + str(exc)

    # Changing only role labels cannot affect decisions: the integrated step discards them.
    def run_with_role(role_values):
        eng = ReferenceEngine(ReferenceConfig(seed=77, max_steps=10))
        eng.governor.set_objective('goal')
        obs = [Observation('route_A','supports','goal',.9,role=role_values[0]),
               Observation('route_B','supports','goal',.7,role=role_values[1])]
        return eng.step(obs,0).target
    role_decisions = [run_with_role(('candidate','candidate')), run_with_role(('evidence','evidence')),
                      run_with_role(('evidence','candidate')), run_with_role(('candidate','evidence'))]
    results['role_intervention_invariance'] = len(set(role_decisions)) == 1
    results['role_intervention_decisions'] = role_decisions

    # Relation content, not label, should drive choice.
    content = ReferenceEngine(ReferenceConfig(seed=88)); content.governor.set_objective('goal')
    d_content = content.step([SimpleNamespace(subject='route_C',predicate='linked',value='goal',strength=.95)],0)
    results['content_change_changes_choice'] = d_content.target == 'route_C'

    # Feedback should alter a later choice under equal structural support.
    def feedback_choice(success_a, success_b):
        eng = ReferenceEngine(ReferenceConfig(seed=99)); eng.governor.set_objective('goal')
        for outcome in success_a: eng.record_action_outcome('route_A', outcome)
        for outcome in success_b: eng.record_action_outcome('route_B', outcome)
        return eng.step([SimpleNamespace(subject='route_A',predicate='supports',value='goal',strength=.8),
                         SimpleNamespace(subject='route_B',predicate='supports',value='goal',strength=.8)],0).target
    positive = feedback_choice([True,True,True],[False,False,False])
    reversed_feedback = feedback_choice([False,False,False],[True,True,True])
    results['feedback_causally_changes_choice'] = positive == 'route_A' and reversed_feedback == 'route_B'
    results['feedback_choices'] = [positive, reversed_feedback]

    # A graph with no path to the objective must fail closed.
    empty = ReferenceEngine(ReferenceConfig(seed=100)); empty.governor.set_objective('goal')
    d_empty = empty.step([SimpleNamespace(subject='route_A',predicate='links',value='elsewhere',strength=.99)],0)
    results['no_goal_path_abstains'] = d_empty.target == 'NO_DECISION'

    # An upstream context node must not be mistaken for an action merely because it points to one.
    ctx = ReferenceEngine(ReferenceConfig(seed=101)); ctx.governor.set_objective('goal')
    d_ctx = ctx.step([SimpleNamespace(subject='route_A',predicate='supports',value='goal',strength=.75),
                      SimpleNamespace(subject='sensor_X',predicate='observes',value='route_A',strength=.99)],0)
    results['upstream_context_not_promoted_to_action'] = d_ctx.target == 'route_A'

    # Paired-seed stress: role interventions must not change decisions in the integrated route.
    paired_role_ok = True
    paired_feedback_ok = True
    for seed in range(100):
        def role_run(roles):
            eng = ReferenceEngine(ReferenceConfig(seed=seed)); eng.governor.set_objective('goal')
            return eng.step([Observation('A','r','goal',.8,role=roles[0]),
                             Observation('B','r','goal',.8,role=roles[1])],0).target
        if len({role_run(x) for x in [('candidate','candidate'),('evidence','evidence'),
                                      ('candidate','evidence'),('evidence','candidate')]}) != 1:
            paired_role_ok = False
        def feedback_run(sa, sb):
            eng = ReferenceEngine(ReferenceConfig(seed=seed)); eng.governor.set_objective('goal')
            for value in sa: eng.record_action_outcome('A', value)
            for value in sb: eng.record_action_outcome('B', value)
            return eng.step([SimpleNamespace(subject='A',predicate='r',value='goal',strength=.8),
                             SimpleNamespace(subject='B',predicate='r',value='goal',strength=.8)],0).target
        if not (feedback_run([1,1,1],[0,0,0]) == 'A' and feedback_run([0,0,0],[1,1,1]) == 'B'):
            paired_feedback_ok = False
    results['paired_role_invariance_100_seeds'] = paired_role_ok
    results['paired_feedback_reversal_100_seeds'] = paired_feedback_ok

    # Outcome feedback delivered through the DKA observation stream must affect the next choice.
    stream = ReferenceEngine(ReferenceConfig(seed=102)); stream.governor.set_objective('goal')
    stream.step([SimpleNamespace(subject='A',predicate='outcome',value='failure',strength=1.0),
                 SimpleNamespace(subject='A',predicate='outcome',value='failure',strength=1.0),
                 SimpleNamespace(subject='B',predicate='outcome',value='success',strength=1.0),
                 SimpleNamespace(subject='B',predicate='outcome',value='success',strength=1.0)],0)
    d_stream = stream.step([SimpleNamespace(subject='A',predicate='supports',value='goal',strength=.8),
                            SimpleNamespace(subject='B',predicate='supports',value='goal',strength=.8)],1)
    results['feedback_stream_reaches_next_decision'] = d_stream.target == 'B'

    # DKA components are still active and the experimental layer is in the decision path.
    results['aaa_memory_and_trace_active'] = (hasattr(e, 'aaa') and hasattr(e, 'memory') and
        hasattr(e, 'role_free_layer') and len(e.trace) == 1)
    countable = [v for k,v in results.items() if isinstance(v, bool)]
    results['passed'] = sum(countable)
    results['total'] = len(countable)
    results['verdict'] = 'PASS_DIAGNOSTIC' if results['passed'] == results['total'] else 'FAIL'
    return results

if __name__ == '__main__':
    print(json.dumps({'branch': EXPERIMENTAL_BRANCH_ID, 'reference_modified': False,
                      'integrated_branch_legacy_scenarios': self_test(),
                      'role_free_integration_tests': role_free_integration_tests()}, ensure_ascii=False, indent=2))
