import importlib.util, json, hashlib, pathlib, sys, random
from types import SimpleNamespace
ROOT=pathlib.Path(__file__).parent
P=ROOT/'RA133_DKA_CAPABILITY_LOOP_REPAIR_V2_EXPERIMENTAL_BRANCH.py'
spec=importlib.util.spec_from_file_location('dka_full_loop_engine',P); m=importlib.util.module_from_spec(spec); sys.modules[spec.name]=m; spec.loader.exec_module(m)
# The scenario registry is the environment, not a selector. Hidden effects are used only by
# the simulator/verifier; DKA receives only raw task and tool descriptions.
CASES=[
 {'id':'L1','task':'cut down the tree','goal_state':'tree_down','tools':[('axe','cuts trees efficiently','low',True,'tree_down'),('knife','cuts food','very_low',True,'food_cut')]},
 {'id':'L2','task':'fell the timber','goal_state':'tree_down','tools':[('saw','brings a tree down','medium',True,'tree_down'),('knife','cuts food','very_low',True,'food_cut')]},
 {'id':'L3','task':'keep the tree standing; do not cut it','goal_state':'tree_standing','tools':[('axe','cuts trees efficiently','low',True,'tree_down'),('fence','protects trees from cutting','low',True,'tree_protected')]},
 {'id':'L4','task':'open the locked door','goal_state':'door_open','tools':[('key','unlocks doors','low',True,'door_open'),('hammer','breaks glass','very_low',True,'glass_broken')]},
 {'id':'L5','task':'make the room brighter','goal_state':'room_lit','tools':[('lamp','illuminates a room','low',True,'room_lit'),('heater','raises room temperature','very_low',True,'room_warm')]},
 {'id':'L6','task':'remove moisture from the clothes','goal_state':'fabric_dry','tools':[('dryer','dries fabric','medium',True,'fabric_dry'),('hose','soaks fabric','very_low',True,'fabric_wet')]},
 {'id':'L7','task':'translate this paragraph into French','goal_state':'translated','tools':[('dictionary','defines words','low',True,'definitions'),('translator','translates paragraphs into French','medium',True,'translated')]},
 {'id':'L8','task':'perform an operation for which no listed tool has the needed effect','goal_state':'unknown_done','tools':[('hammer','breaks glass','low',True,'glass_broken'),('lamp','illuminates a room','low',True,'room_lit')]},
 {'id':'L9','task':'open the door','goal_state':'door_open','tools':[('key','unlocks doors','low',False,'door_open'),('pick','opens doors','medium',True,'door_open')]},
 {'id':'L10','task':'cut down the tree','goal_state':'tree_down','tools':[('axe','cuts trees efficiently','high',True,'tree_down'),('saw','brings a tree down','low',True,'tree_down')]},
 {'id':'L11','task':'make the liquid colder','goal_state':'liquid_cold','tools':[('chiller','lowers liquid temperature','medium',True,'liquid_cold'),('heater','heats liquid','very_low',True,'liquid_hot')]},
 {'id':'L12','task':'raise the crate','goal_state':'crate_up','tools':[('jack','lifts crates','low',True,'crate_up'),('rope','ties objects','very_low',True,'object_tied')]},
]
def sim(case, toolname):
    tool=next((t for t in case['tools'] if t[0]==toolname),None)
    state={'achieved':False,'world_effects':[]}
    if tool is None: return {'invoked':False,'reported':'none','state':state,'cost':0}
    name,desc,cost,avail,effect=tool
    if not avail: return {'invoked':False,'reported':'unavailable','state':state,'cost':0}
    # Simulate a selected tool. A tool may be invoked but still fail to achieve goal.
    state['world_effects'].append(effect); state['achieved']=(effect==case['goal_state'])
    return {'invoked':True,'reported':'success','state':state,'cost':{'very_low':.02,'low':.1,'medium':.3,'high':.7,'very_high':.95}.get(cost,.3)}
def make_obs(case):
    rows=[m.Observation('task','task_goal',case['task'],.95,source='user_task')]
    for name,desc,cost,avail,effect in case['tools']:
        rows += [m.Observation('environment','available_resource' if avail else 'unavailable_resource',name,.95,source='tool_inventory'),
                 m.Observation(name,'capability',desc,.9,source='tool_description'),
                 m.Observation(name,'cost_level',cost,1,source='tool_inventory')]
    return rows
results=[]
for idx,c in enumerate(CASES):
    eng=m.ReferenceEngine(m.ReferenceConfig(seed=62000+idx,max_steps=8))
    # No task success labels, effect-family labels, or gold semantic annotations enter DKA.
    eng.governor.set_objective(c['task'])
    obs=make_obs(c)
    d=eng.step(obs,0)
    candidates=dict(getattr(eng.role_free_layer,'last_candidates',{}))
    selected=d.target if any(t[0]==d.target for t in c['tools']) else None
    action=sim(c,selected) if selected else {'invoked':False,'reported':'no_dka_tool_choice','state':{'achieved':False,'world_effects':[]},'cost':0}
    verified=bool(action['state']['achieved']) # independently computed from simulated world effect vs hidden goal state
    # Feedback enters DKA as observations, then a second internal step re-evaluates via memory/AAA/Governor.
    fb=[m.Observation(selected or 'no_action','action_outcome','success' if action.get('invoked') and verified else 'failure',.99,source='environment_feedback'),
        m.Observation('environment','goal_met','true' if verified else 'false',.99,source='independent_verifier'),
        m.Observation('environment','task_state','achieved' if verified else 'unmet',.99,source='independent_verifier')]
    d2=eng.step(fb,1)
    # For loop integrity, confirm feedback is in memory and AAA has been run (step trace grows).
    feedback_memory=any(k[1] in {'action_outcome','goal_met','task_state'} for k in eng.memory.items.keys())
    results.append({'case':c['id'],'raw_task':c['task'],'tool_descriptions':[{'name':t[0],'description':t[1],'available':t[3],'cost':t[2]} for t in c['tools']],
      'dka_directive_step0':d.target,'dka_candidates':candidates,'dka_selected_listed_tool':selected,
      'tool_invoked':action['invoked'],'tool_report':action['reported'],'independent_goal_verified':verified,
      'expected_goal_state':c['goal_state'],'actual_effects':action['state']['world_effects'],'cost':action['cost'],
      'feedback_returned_to_dka':True,'feedback_present_in_memory':feedback_memory,'reevaluation_directive_step1':d2.target,
      'aaa_governor_steps':len(eng.trace),'full_loop_success':bool(selected and action['invoked'] and verified and feedback_memory and len(eng.trace)>=2),
      'failure_stage':('none' if selected and action['invoked'] and verified and feedback_memory else 'raw-text-to-action-selection' if not selected else 'invocation-or-world-verification')})
summary={'cases':len(results),'selected_tool':sum(bool(r['dka_selected_listed_tool']) for r in results),'invoked':sum(r['tool_invoked'] for r in results),'verified_goal':sum(r['independent_goal_verified'] for r in results),'feedback_memory':sum(r['feedback_present_in_memory'] for r in results),'full_loop_success':sum(r['full_loop_success'] for r in results),'false_successes':sum(bool(r['tool_invoked'] and r['tool_report']=='success' and not r['independent_goal_verified']) for r in results),'safe_abstentions':sum(bool(not r['dka_selected_listed_tool'] and not r['tool_invoked']) for r in results)}
report={'test':'DKA_FULL_CAPABILITY_LOOP_RAW_TEXT_V1','engine_branch':P.name,'engine_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'frozen_RA_1_3_3_sha256':hashlib.sha256((ROOT/'DYNAMIC_KNOWLEDGE_ARCHITECTURE_RA1_3_3_EXPLICIT_ABSTENTION(1).py').read_bytes()).hexdigest(),'reference_modified':False,'semantic_annotations_supplied_to_DKA':False,'external_selector_used':False,'external_executor_and_verifier':True,'executor_role':'executes only the exact DKA directive; never selects or substitutes a tool','verifier_role':'compares hidden simulated world effect with hidden goal state','cases':results,'summary':summary,'verdict':'FULL_LOOP_NOT_DEMONSTRATED' if summary['full_loop_success']<len(results) else 'SYNTHETIC_FULL_LOOP_PASS_LIMITED','limitations':['Synthetic environment and hand-authored task/tool descriptions.','Execution simulator and independent verifier are external test harness components; only the DKA directive selects the tool.','The current engine has no demonstrated native capability-annotation extraction API.','Second step proves feedback was processed into DKA memory/trace, not that it causally improved the next decision.','No real-world tools were invoked.']}
out=ROOT/'DKA_FULL_CAPABILITY_LOOP_V1_RESULTS.json'; out.write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'summary':summary,'verdict':report['verdict'],'engine_sha256':report['engine_sha256'],'frozen_reference_sha256':report['frozen_RA_1_3_3_sha256'],'cases':[{k:r[k] for k in ['case','dka_directive_step0','dka_selected_listed_tool','tool_invoked','independent_goal_verified','feedback_present_in_memory','reevaluation_directive_step1','full_loop_success','failure_stage']} for r in results]},ensure_ascii=False,indent=2))
