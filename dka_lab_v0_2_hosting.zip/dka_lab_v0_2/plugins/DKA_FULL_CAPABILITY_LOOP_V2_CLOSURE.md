# DKA Full Capability Loop V2 — Repair Closure

## Decision
**PARTIAL REPAIR — NOT ADOPTED.** This experimental branch repairs action-space contamination and adds conservative inflection normalization. It does not demonstrate general natural-language capability extraction.

## Integrity
- Experimental branch: `RA133_DKA_CAPABILITY_LOOP_REPAIR_V2_EXPERIMENTAL_BRANCH.py`
- Branch SHA-256: `22235e9beace367e7101e5bedd09b75b5bddb17523caaa40fa6abb4117537c01`
- Frozen RA-1.3.3 SHA-256: `beb566fbbb6e7bfd86848bb4b4f86393ef375d5672b3028d62bd6cfb86c6b5a9` (unchanged)
- Test driver: `run_full_capability_loop_v2.py`
- Test cases: 12 synthetic raw-text cases; no gold semantic labels passed to DKA; no external selector used.
- Executor/verifier: external simulator and independent hidden-state check, used only after DKA's exact tool directive.

## Results
- Listed tool selected: **7/12**
- Tool invoked: **7/12**
- Goal independently verified: **7/12**
- Full successful tool loops: **7/12**
- Feedback stored in memory: **12/12**
- False successes: **0**
- No-tool abstentions: **5/12**

Successful cases: L1, L4, L5, L7, L9, L10, L11.

Abstention was appropriate in L3 (the task explicitly says not to cut the tree; the listed effects do not establish the requested standing state) and L8 (no listed tool has the required effect). Over-abstention remains in L2 (fell timber vs. saw brings tree down), L6 (remove moisture vs. dryer dries fabric), and L12 (raise crate vs. jack lifts crates).

## Repair made
1. Separated goal-discovery investigative hypotheses from the executable tool-choice action space when an explicit task and tool inventory are present.
2. Filtered the task-bearing graph subject (`task`) from executable candidates; it had been selected as if it were an action.
3. Added conservative regular inflection normalization for verb forms and plurals; no synonym expansion was used to claim semantic understanding.
4. Corrected L3's inconsistent hidden goal label: the natural-language task says to keep the tree standing, so its verifier goal is now `tree_standing`, not `tree_down`.

## Remaining defects
- Semantic relations such as *fell timber* ↔ *saw brings a tree down*, *remove moisture* ↔ *dry*, and *raise* ↔ *lift* remain unresolved.
- The memory receives outcome feedback, but this run does **not** prove that feedback causally improves a later decision.
- All execution is synthetic; no real tool was called.

## Closure
- Status: routing defect repaired in an experimental branch; full loop still **FAIL / NOT DEMONSTRATED**.
- Evidence: successful loops improved from 0/12 to 7/12; false successes remained 0; 3 cases still over-abstain and 2 cases appropriately abstain.
- Decision: **keep experimental; do not merge; do not modify RA-1.3.3.**
- Next defect to isolate: generalized effect extraction across paraphrases without adding hand-written synonym pairs; then a separate causal feedback test.