#!/usr/bin/env python3
"""V2 experimental repair: isolate goal-discovery investigation actions from tool choice.
Derived from V4 without modifying V4 or frozen RA-1.3.3.
This fixes a routing defect only; it does not claim general language understanding.
"""
from __future__ import annotations
import importlib.util, pathlib, sys
BASE = pathlib.Path(__file__).with_name('RA133_DKA_CAPABILITY_EFFECT_GATE_V4_EXPERIMENTAL_BRANCH.py')
spec = importlib.util.spec_from_file_location('dka_loop_repair_v4_base', BASE)
base = importlib.util.module_from_spec(spec); sys.modules[spec.name] = base; spec.loader.exec_module(base)

Observation = base.Observation
ReferenceConfig = base.ReferenceConfig

class _RoutedGoalDiscovery:
    def __init__(self, original): self.original = original
    def infer(self, observations):
        rows = list(observations or [])
        tool_mode = (
            any(str(o.subject).lower() in {'task','goal','user'} and str(o.predicate).lower() in {'goal','task_goal','objective','requires'} for o in rows)
            and any(str(o.predicate).lower() in {'capability','can_do','function'} for o in rows)
            and any(str(o.predicate).lower() in {'available_resource','available_tool','tool_available','unavailable_resource','unavailable_tool'} for o in rows)
        )
        # In tool-selection mode, do not inject a generic investigation hypothesis
        # into the same action space as executable tool IDs. The role-free capability
        # layer remains responsible for choosing an actual listed tool or abstaining.
        if tool_mode:
            return None
        return self.original.infer(rows)

class _ToolChoiceDecisionLayer(base.RoleFreeDecisionLayer):
    ACTION_FAMILIES = dict(base.RoleFreeDecisionLayer.ACTION_FAMILIES, translate=('translate', 1))

    @staticmethod
    def _normalize_token(token):
        t = token.lower()
        if t == 'colder': return 'cool'
        if len(t) > 5 and t.endswith('ies'): return t[:-3] + 'y'
        if len(t) > 3 and t.endswith('s') and not t.endswith('ss'): return t[:-1]
        if len(t) > 5 and t.endswith('ing'): return t[:-3]
        if len(t) > 4 and t.endswith('ed'): return t[:-2]
        if len(t) > 5 and t.endswith('er') and t[:-2] in {'bright','dark','warm','cold','high','low','fast','slow'}:
            return t[:-2] + ('en' if t[:-2] == 'bright' else '')
        return t

    @classmethod
    def _effect_signature(cls, text):
        import re
        raw = [x for x in re.split(r'[^a-z0-9]+', str(text).lower().replace('_',' ')) if x]
        toks = [cls._normalize_token(x) for x in raw]
        found = [(i, cls.ACTION_FAMILIES[t]) for i,t in enumerate(toks) if t in cls.ACTION_FAMILIES]
        if not found: return None
        i, (family, direction) = found[0]
        if any(t in cls.NEGATORS for t in toks[:i]): direction *= -1
        objects = set(toks[i+1:]) - {'a','an','the','to','of','from','into','on','in','with','for','by','and','efficiently','efficient'}
        return family, direction, objects

    def infer(self, observations, objective):
        rows = list(observations or [])
        result = super().infer(rows, objective)
        tool_mode = (
            any(str(o.subject).lower() in {'task','goal','user'} and str(o.predicate).lower() in {'goal','task_goal','objective','requires'} for o in rows)
            and any(str(o.predicate).lower() in {'capability','can_do','function'} for o in rows)
        )
        if tool_mode:
            # Prevent the graph's goal-bearing subject (e.g. 'task') from being
            # mistaken for an executable action. Keep only listed capability IDs.
            tool_ids = {str(o.subject) for o in rows if str(o.predicate).lower() in {'capability','can_do','function'}}
            result = {k:v for k,v in result.items() if k in tool_ids}
            self.last_candidates = dict(result)
        return result

class ReferenceEngine(base.ReferenceEngine):
    def __init__(self, config=None):
        super().__init__(config)
        self.goal_discovery = _RoutedGoalDiscovery(self.goal_discovery)
        self.role_free_layer = _ToolChoiceDecisionLayer()

__all__ = ['Observation','ReferenceConfig','ReferenceEngine']
