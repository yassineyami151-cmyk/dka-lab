# DKA Lab v0.2 — independent host with real RA-1.3.3 adapter

## What is implemented
- Responsive, offline-friendly lab UI with a 3D-styled scene, task/observation editor, execution output, trace and run log.
- Local Python host API using only the Python standard library.
- Actual adapter to the frozen RA-1.3.3 engine source recovered from the Library.
- Startup SHA-256 gate: the bundled reference must match `beb566fbbb6e7bfd86848bb4b4f86393ef375d5672b3028d62bd6cfb86c6b5a9` or the host refuses to start.
- Separate plugin contract and isolated folder for experimental/future engines.

## What is not claimed
- The scene is a 3D-styled visualization, not a full WebGL/Three.js renderer.
- RA-1.3.3 has no explicit learning API. The host exposes this honestly as `learn: false`.
- The V2 capability loop is included as experimental source/reference only; it is not live-wired into the runtime and its last closure was partial (7/12 full loops, 3 over-abstentions, 2 appropriate abstentions; causal feedback improvement unproven).
- Arbitrary uploaded code is not safely sandboxed in this prototype. Only run trusted local code. Production isolation is required.

## Run on a computer
1. Install Python 3.10+.
2. Extract this folder.
3. Run `python server.py` (Windows: `py server.py` also works).
4. Open `http://127.0.0.1:8765` in the same computer's browser.
5. Press **Test connection**, then run a task. `python tests/smoke_test.py` tests the engine and API.

Opening `index.html` directly via `file://` will show the UI but cannot call the local API; start `server.py` first.

## Current interface input
The JSON editor accepts observations with required fields `subject`, `predicate`, `value`, and optional `strength` (0..1), `source`, `timestamp`, `role`. This passes observations to the actual RA-1.3.3 `ReferenceEngine.step()` and shows its real directive and trace. It does not translate free natural language into engine observations.

## Integrity
Reference source SHA-256: `beb566fbbb6e7bfd86848bb4b4f86393ef375d5672b3028d62bd6cfb86c6b5a9`.
The engine file was copied byte-for-byte; no edits were made to its source.
