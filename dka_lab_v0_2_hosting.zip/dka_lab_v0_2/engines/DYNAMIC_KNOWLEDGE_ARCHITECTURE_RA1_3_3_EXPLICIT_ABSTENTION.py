#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SUN DYNAMIC ARCHITECTURE — REFERENCE ENGINE RA-1.0
==================================================
Single frozen reference engine for Governor/AAA architectural experiments.

RULE: tests may change only their scenario/input stream. They must not replace
or modify the internal architecture components.

Architecture:
Governor -> Observe -> Reason -> Directive
              ^
              |
      Memory <-> AAA <-> Linear/Nonlinear
              ^
              |
          Noise / Spiral

AAA = Analysis + Audit + Association
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple
import hashlib, json, math, random

REFERENCE_ENGINE_VERSION = "RA-1.3.3-EXPLICIT-ABSTENTION"
ARCHITECTURE_ID = "GOVERNOR-AAA-MEMORY-DYNAMIC"
DEFAULT_SEED = 73019

@dataclass(frozen=True)
class ReferenceConfig:
    seed: int = DEFAULT_SEED
    frustration_threshold: float = 3.0
    memory_capacity: int = 256
    base_retention: float = 0.985
    forgetting_floor: float = 0.08
    forgetting_rate: float = 0.035
    association_threshold: float = 0.28
    audit_penalty: float = 0.12
    contradiction_penalty: float = 0.22
    novelty_bonus: float = 0.06
    linear_weight: float = 0.45
    nonlinear_weight: float = 0.55
    spiral_step: float = 1.0
    spiral_turn: float = math.pi / 2.0
    noise_floor: float = 0.02
    noise_ceiling: float = 0.35
    reassessment_gain: float = 0.35
    max_steps: int = 256
    danger_cost_threshold: float = 0.80
    danger_priority_gain: float = 1.50
    expected_loss_trigger: float = 0.80
    irreversible_danger_floor: float = 0.50

@dataclass
class Observation:
    subject: str
    predicate: str
    value: Any
    strength: float = 1.0
    source: str = "environment"
    timestamp: int = 0
    role: str = "candidate"  # candidate = selectable target; evidence = supporting context

@dataclass
class MemoryItem:
    subject: str
    predicate: str
    value: Any
    confidence: float
    last_seen: int
    uses: int = 0
    contradictions: int = 0
    origin: str = "observation"
    role: str = "candidate"
    @property
    def key(self): return (self.subject, self.predicate)

@dataclass
class Relation:
    left: Tuple[str, str]
    right: Tuple[str, str]
    score: float
    evidence: int = 1
    active: bool = True
    last_reassessed: int = 0

@dataclass
class Directive:
    target: str
    objective: str
    priority: float
    reason: str
    step: int

@dataclass
class StepRecord:
    step: int
    observation_count: int
    memory_size: int
    relation_count: int
    best_relation: float
    noise: float
    forgetting_lambda: float
    linear_score: float
    nonlinear_score: float
    directive_target: str
    directive_objective: str
    reassessed: int
    contradictions: int

@dataclass
class RunResult:
    engine_version: str
    architecture_id: str
    seed: int
    scenario: str
    config_hash: str
    steps: List[StepRecord]
    final_directive: Optional[Directive]
    success: bool
    metrics: Dict[str, float]
    notes: List[str] = field(default_factory=list)
    def to_json(self):
        return json.dumps({
            "engine_version": self.engine_version,
            "architecture_id": self.architecture_id,
            "seed": self.seed,
            "scenario": self.scenario,
            "config_hash": self.config_hash,
            "success": self.success,
            "metrics": self.metrics,
            "notes": self.notes,
            "final_directive": asdict(self.final_directive) if self.final_directive else None,
            "steps": [asdict(x) for x in self.steps],
        }, ensure_ascii=False, indent=2)

class ReferenceMemory:
    """Persistent relational memory with fixed dynamic-forgetting policy."""
    def __init__(self, cfg):
        self.cfg = cfg
        self.items: Dict[Tuple[str,str], MemoryItem] = {}
        self.relations: Dict[Tuple[Tuple[str,str],Tuple[str,str]], Relation] = {}

    def observe(self, obs, step):
        key = (obs.subject, obs.predicate)
        if key not in self.items:
            if len(self.items) >= self.cfg.memory_capacity:
                self._evict_lowest()
            self.items[key] = MemoryItem(obs.subject, obs.predicate, obs.value,
                                         max(0.0,min(1.0,obs.strength)), step,
                                         role=obs.role)
            return
        item = self.items[key]
        if item.value != obs.value:
            item.contradictions += 1
            item.confidence *= (1.0-self.cfg.contradiction_penalty)
        else:
            item.confidence += (1.0-item.confidence)*0.30*obs.strength
        item.value, item.last_seen, item.uses = obs.value, step, item.uses+1
        item.role = obs.role

    def _evict_lowest(self):
        if not self.items: return
        k=min(self.items, key=lambda x:self.items[x].confidence)
        del self.items[k]

    @staticmethod
    def _compat(a,b):
        if a == b: return 1.0
        if isinstance(a,(int,float)) and isinstance(b,(int,float)):
            return 1.0/(1.0+abs(float(a)-float(b)))
        sa=set(str(a).lower().replace(',',' ').split())
        sb=set(str(b).lower().replace(',',' ').split())
        return len(sa&sb)/len(sa|sb) if sa and sb else 0.0

    def add_relation(self,left,right,score,step):
        if left == right: return
        key=tuple(sorted((left,right)))
        if key not in self.relations:
            self.relations[key]=Relation(key[0],key[1],max(0,min(1,score)),1,True,step)
        else:
            r=self.relations[key]
            r.score=max(0,min(1,0.65*r.score+0.35*score))
            r.evidence += 1; r.last_reassessed=step; r.active=True

    def dynamic_forgetting(self,step,frustration):
        pressure=max(0,min(1,frustration/10.0))
        lam=max(self.cfg.forgetting_floor,
                min(.999,self.cfg.base_retention-self.cfg.forgetting_rate*pressure))
        for item in self.items.values():
            age=max(0,step-item.last_seen)
            item.confidence *= lam ** max(1,age*0.15)
        stale=[k for k,v in self.items.items() if v.confidence<.015 and step-v.last_seen>8]
        for k in stale: del self.items[k]
        return lam

    def reassess_relations(self,step):
        changed=0
        for r in self.relations.values():
            if r.left not in self.items or r.right not in self.items:
                r.active=False; continue
            a,b=self.items[r.left],self.items[r.right]
            new=self._compat(a.value,b.value)
            old=r.score
            r.score=(1-self.cfg.reassessment_gain)*old+self.cfg.reassessment_gain*new
            r.last_reassessed=step; r.active=r.score>=.03
            if abs(r.score-old)>.05: changed+=1
        return changed

    def strongest_relation(self):
        vals=[r.score for r in self.relations.values() if r.active]
        return max(vals) if vals else 0.0

class AAA:
    def __init__(self,cfg): self.cfg=cfg
    def analysis(self,obs,memory):
        if not obs:return {"novelty":0.0,"coherence":0.0}
        known=sum((o.subject,o.predicate) in memory.items for o in obs)
        novelty=1-known/len(obs)
        unique=len(set(str(o.value) for o in obs))
        return {"novelty":novelty,"coherence":1/max(1,unique)}
    def audit(self,obs,memory):
        contradictions=sum(1 for o in obs if (o.subject,o.predicate) in memory.items
                           and memory.items[(o.subject,o.predicate)].value != o.value)
        rate=contradictions/max(1,len(obs))
        return {"contradictions":float(contradictions),"audit_score":max(0,1-rate*self.cfg.audit_penalty*5)}
    def association(self,obs,memory,step):
        keys=[(o.subject,o.predicate) for o in obs if (o.subject,o.predicate) in memory.items]
        created=0
        for i in range(len(keys)):
            for j in range(i+1,len(keys)):
                a,b=memory.items[keys[i]],memory.items[keys[j]]
                score=memory._compat(a.value,b.value)
                if a.subject==b.subject: score=max(score,.55)
                if a.predicate==b.predicate: score=max(score,.45)
                if score>=self.cfg.association_threshold:
                    memory.add_relation(keys[i],keys[j],score,step); created+=1
        return created

class LinearReasoner:
    def __init__(self,cfg): self.cfg=cfg
    def score(self,obs):
        return sum(max(0,min(1,o.strength)) for o in obs)/len(obs) if obs else 0.0

class NonlinearReasoner:
    def __init__(self,cfg): self.cfg=cfg
    def score(self,obs,memory):
        if not obs:return 0.0
        novelty=len({(o.subject,o.predicate) for o in obs})/len(obs)
        return max(0,min(1,memory.strongest_relation()*(.5+.5*novelty)))

class Spiral:
    def __init__(self,cfg): self.cfg=cfg; self.angle=0.0; self.radius=0.0
    def advance(self):
        self.angle+=self.cfg.spiral_turn; self.radius+=self.cfg.spiral_step
        return self.radius*math.cos(self.angle),self.radius*math.sin(self.angle)

class NoiseController:
    def __init__(self,cfg): self.cfg=cfg; self.level=cfg.noise_floor
    def update(self,frustration):
        p=max(0,min(1,frustration/10.0))
        self.level=self.cfg.noise_floor+p*(self.cfg.noise_ceiling-self.cfg.noise_floor)
        return self.level

class Governor:
    """Primary objective holder; AAA informs it but does not replace it."""
    def __init__(self,cfg):
        self.cfg=cfg; self.primary_objective='explore'; self.current_target='environment'
        self.frustration=0.0; self.directive_history=[]
        self.pre_safety_target=None; self.safety_active=False
    def set_objective(self,objective):
        self.primary_objective=objective
        if not self.directive_history and self.current_target=='environment': self.current_target=objective
    def update_frustration(self,progress):
        self.frustration=max(0,self.frustration-progress*2) if progress>.05 else self.frustration+1
    def risk_fusion(self, observations):
        danger=0.0; p_failure=0.0; failure_cost=0.0; irreversible=False
        for o in observations:
            pred=str(o.predicate).lower().replace('-','_').strip()
            val=str(o.value).lower().strip()
            if pred in {'danger','imminent','hazard'}:
                danger=max(danger,max(0.0,min(1.0,float(o.strength))))
            if pred in {'failure_probability','failure_prob','p_failure'}:
                try: p_failure=max(p_failure,max(0.0,min(1.0,float(o.value))))
                except (TypeError,ValueError): pass
            if pred in {'failure_cost','cost_of_failure','damage_cost'}:
                try: failure_cost=max(failure_cost,max(0.0,float(o.value)))
                except (TypeError,ValueError): pass
            if pred in {'unrecoverable','irreversible'} or val in {'unrecoverable','irreversible','fatal','permanent'}:
                irreversible=True
        expected_loss=p_failure*failure_cost
        loss_score=1.0-math.exp(-expected_loss) if expected_loss>0 else 0.0
        if irreversible: loss_score=max(loss_score,danger)
        trigger=(danger>=self.cfg.danger_cost_threshold or
                 loss_score>=self.cfg.expected_loss_trigger or
                 (irreversible and danger>=self.cfg.irreversible_danger_floor))
        return {'danger':danger,'p_failure':p_failure,'failure_cost':failure_cost,
                'expected_loss':expected_loss,'loss_score':loss_score,
                'irreversible':irreversible,'trigger':trigger}
    def decide(self,step,linear_score,nonlinear_score,memory,audit_score,observations=()):
        risk=self.risk_fusion(observations)
        if risk['trigger']:
            if not self.safety_active:
                self.pre_safety_target=self.current_target
            self.safety_active=True
            self.frustration=max(self.frustration,risk['danger']*self.cfg.danger_priority_gain)
            d=Directive('SAFETY','SAFETY',min(1.0,max(risk['danger'],risk['loss_score'])),
                f"risk_fusion; danger={risk['danger']:.3f}; expected_loss={risk['expected_loss']:.3f}; irreversible={risk['irreversible']}",step)
            self.current_target='SAFETY'; self.directive_history.append(d); return d
        if self.safety_active:
            # Safety is a temporary override. On clearance, restore the pre-hazard target
            # and bypass stale hazard-derived associations for this recovery decision.
            target=self.pre_safety_target or 'environment'
            self.current_target=target; self.safety_active=False; self.pre_safety_target=None
            d=Directive(target,self.primary_objective,1.0,'safety_cleared; restore_pre_safety_target',step)
            self.directive_history.append(d); return d
        combined=self.cfg.linear_weight*linear_score+self.cfg.nonlinear_weight*nonlinear_score
        # RA-1.2: decision routing must use present evidence, not relation strength alone.
        # A candidate directly supported in this step receives a bounded support bonus;
        # candidates absent from current evidence do not get that bonus.
        current_support={}
        current_evidence=set()
        for obs in observations:
            key=(obs.subject,obs.predicate)
            if str(obs.role).lower() == "candidate":
                current_support[key]=max(current_support.get(key,0.0),max(0.0,min(1.0,float(obs.strength))))
            elif str(obs.role).lower() == "evidence":
                current_evidence.add(key)
        candidates=[]
        for r in memory.relations.values():
            if not r.active: continue
            # Candidate selection must have a current causal path: either direct
            # candidate support now, or a strong relation to evidence observed now.
            for key, other in ((r.left,r.right),(r.right,r.left)):
                item=memory.items.get(key)
                if not item or item.role != "candidate":
                    continue
                direct=current_support.get(key,0.0)>0.0
                # A stale relation score is insufficient: validate compatibility against
                # the evidence value as it exists in this step.
                other_item=memory.items.get(other)
                indirect=(other in current_evidence and other_item is not None
                          and memory._compat(item.value, other_item.value) >= 0.55)
                if not (direct or indirect):
                    continue
                relation_score=r.score*item.confidence*(.5+.5*audit_score)
                evidence_bonus=.40*current_support.get(key,0.0)
                candidates.append((item.subject,relation_score+evidence_bonus, key, relation_score, evidence_bonus))
        if candidates:
            target,score,_,_,_=max(candidates,key=lambda x:x[1])
            priority=max(0,min(1,.55*min(1.0,score)+.45*combined))
        else:
            # Explicit fail-closed behavior: no currently supported candidate means
            # no action recommendation. Keep the objective as internal recovery anchor,
            # but do not present it as an evidence-backed decision.
            self.current_target=self.primary_objective
            d=Directive('NO_DECISION',self.primary_objective,0.0,
                        f'insufficient_current_evidence; request_new_search; combined={combined:.4f}; audit={audit_score:.4f}',step)
            self.directive_history.append(d)
            return d
        d=Directive(target,self.primary_objective,priority,
                    f'primary={self.primary_objective}; combined={combined:.4f}; audit={audit_score:.4f}',step)
        self.current_target=target; self.directive_history.append(d); return d

class ReferenceEngine:
    VERSION=REFERENCE_ENGINE_VERSION; ARCHITECTURE=ARCHITECTURE_ID
    def __init__(self,config=None):
        self.cfg=config or ReferenceConfig(); self._rng=random.Random(self.cfg.seed)
        self.memory=ReferenceMemory(self.cfg); self.aaa=AAA(self.cfg)
        self.linear=LinearReasoner(self.cfg); self.nonlinear=NonlinearReasoner(self.cfg)
        self.spiral=Spiral(self.cfg); self.noise=NoiseController(self.cfg); self.governor=Governor(self.cfg)
        self.trace=[]
    def config_hash(self):
        return hashlib.sha256(json.dumps(asdict(self.cfg),sort_keys=True).encode()).hexdigest()[:16]
    def fingerprint(self):
        payload={"version":self.VERSION,"architecture":self.ARCHITECTURE,
                 "config":asdict(self.cfg),"components":[type(self.memory).__name__,type(self.aaa).__name__,
                 type(self.linear).__name__,type(self.nonlinear).__name__,type(self.spiral).__name__,
                 type(self.noise).__name__,type(self.governor).__name__]}
        return hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
    def step(self,observations,step):
        for o in observations:self.memory.observe(o,step)
        analysis=self.aaa.analysis(observations,self.memory); audit=self.aaa.audit(observations,self.memory)
        self.aaa.association(observations,self.memory,step)
        reassessed=self.memory.reassess_relations(step)
        linear=self.linear.score(observations); nonlinear=self.nonlinear.score(observations,self.memory)
        progress=max(0,.5*analysis['coherence']+.5*self.memory.strongest_relation())
        self.governor.update_frustration(progress); noise=self.noise.update(self.governor.frustration)
        lam=self.memory.dynamic_forgetting(step,self.governor.frustration); self.spiral.advance()
        # Risk Fusion is part of Governor decision fusion; safety override is temporary.
        risk=self.governor.risk_fusion(observations)
        if risk['trigger']:
            self.governor.frustration=max(self.governor.frustration,risk['danger']*self.cfg.danger_priority_gain)
        d=self.governor.decide(step,linear,nonlinear,self.memory,audit['audit_score'],observations)
        self.trace.append(StepRecord(step,len(observations),len(self.memory.items),len(self.memory.relations),
                                     self.memory.strongest_relation(),noise,lam,linear,nonlinear,
                                     d.target,d.objective,reassessed,int(audit['contradictions'])))
        return d
    def run(self,scenario):
        self.governor.set_objective(scenario.objective)
        for step in range(self.cfg.max_steps):
            obs=scenario.observations(step)
            if obs is None: break
            self.step(obs,step)
            if scenario.stop(self,step): break
        return RunResult(self.VERSION,self.ARCHITECTURE,self.cfg.seed,scenario.name,self.config_hash(),
                         self.trace,self.governor.directive_history[-1] if self.governor.directive_history else None,
                         scenario.success(self),scenario.metrics(self),scenario.notes)

class Scenario:
    name='abstract'; objective='explore'; notes=[]
    def observations(self,step): raise NotImplementedError
    def stop(self,engine,step): return step>=20
    def success(self,engine): return False
    def metrics(self,engine): return {'steps':float(len(engine.trace)),'memory_size':float(len(engine.memory.items)),
                                      'relations':float(len(engine.memory.relations)),'max_relation':engine.memory.strongest_relation()}

class ReturnOfBScenario(Scenario):
    name='fingerprint_return_of_B'; objective='energy'; notes=['B is never explicitly labelled correct.']
    def observations(self,s):
        if s==0:return [Observation('energy','source','chemical',1,role='evidence'),Observation('A','linked_to','energy',.9,role='candidate')]
        if s==1:return [Observation('B','linked_to','unknown',.6,role='candidate')]
        if s in (2,3):return [Observation('B','linked_to','energy',.95,role='candidate'),Observation('bioelectric','related_to','energy',.9,role='evidence')]
        if s>=4:return [Observation('B','linked_to','energy',.98,role='candidate')]
        return None
    def stop(self,e,s): return s>=6
    def success(self,e): return e.governor.current_target=='B' and len(e.memory.relations)>0
    def metrics(self,e):
        m=super().metrics(e); b=e.memory.items.get(('B','linked_to')); m['B_confidence']=b.confidence if b else 0; m['B_selected']=float(e.governor.current_target=='B'); return m

class InversionScenario(Scenario):
    name='forced_inversion'; objective='energy'; notes=['Misleading route starts stronger; later evidence changes the landscape.']
    def observations(self,s):
        if s==0:return [Observation('energy','source','X',1,role='evidence'),Observation('wrong','route','energy',1,role='candidate'),Observation('right','route','noise',.2,role='candidate')]
        if s in (1,2):return [Observation('wrong','route','energy',1,role='candidate')]
        if s in (3,4,5):return [Observation('right','route','energy',1,role='candidate'),Observation('bio','process','energy',1,role='evidence')]
        return None
    def stop(self,e,s): return s>=7
    def success(self,e): return e.governor.current_target=='right'
    def metrics(self,e):
        m=super().metrics(e); m['final_target_right']=float(e.governor.current_target=='right'); return m

class DynamicForgettingScenario(Scenario):
    name='dynamic_forgetting'; objective='target'; notes=['Tests time-varying retention without changing the engine.']
    def observations(self,s):
        if s<3:return [Observation('old_path','supports','target',1)]
        if s<9:return [Observation('new_path','supports','target',.95)]
        if s in (9,10):return [Observation('new_path','supports','target',1),Observation('old_path','supports','closed',.05)]
        return None
    def stop(self,e,s): return s>=12
    def success(self,e):
        old=e.memory.items.get(('old_path','supports')); new=e.memory.items.get(('new_path','supports'))
        return bool(new and (not old or new.confidence>=old.confidence))
    def metrics(self,e):
        m=super().metrics(e); old=e.memory.items.get(('old_path','supports')); new=e.memory.items.get(('new_path','supports'))
        m['old_confidence']=old.confidence if old else 0; m['new_confidence']=new.confidence if new else 0; return m

class CrossDomainAssociationScenario(Scenario):
    name='cross_domain_AAA'; objective='energy'; notes=['Governor retains the primary objective while AAA builds cross-domain relations.']
    def observations(self,s):
        if s==0:return [Observation('energy','domain','chemical',1),Observation('reaction','produces','energy',.9)]
        if s==1:return [Observation('glow','domain','biological',.8),Observation('glow','contains','electrical',.9)]
        if s==2:return [Observation('bioelectric','domain','electrical',1),Observation('bioelectric','related','energy',1)]
        if s>=3:return [Observation('bioelectric','related','energy',1)]
        return None
    def stop(self,e,s): return s>=6
    def success(self,e): return len(e.memory.relations)>=2
    def metrics(self,e):
        m=super().metrics(e); m['cross_domain_relations']=float(len(e.memory.relations));
        m['objective_preserved']=float(all(d.objective==self.objective for d in e.governor.directive_history)); return m

def run_same_engine(scenarios,config=None):
    results=[]
    for scenario in scenarios:
        results.append(ReferenceEngine(config).run(scenario))
    return results

def reference_suite(config=None):
    scenarios=[ReturnOfBScenario(),InversionScenario(),DynamicForgettingScenario(),CrossDomainAssociationScenario()]
    results=run_same_engine(scenarios,config)
    ids={(r.engine_version,r.architecture_id,r.config_hash) for r in results}
    assert len(ids)==1,'REFERENCE VIOLATION: different engine/config detected.'
    return results

def self_test():
    cfg=ReferenceConfig(); e=ReferenceEngine(cfg)
    expected={'ReferenceMemory','AAA','LinearReasoner','NonlinearReasoner','Spiral','NoiseController','Governor'}
    actual={type(e.memory).__name__,type(e.aaa).__name__,type(e.linear).__name__,type(e.nonlinear).__name__,
            type(e.spiral).__name__,type(e.noise).__name__,type(e.governor).__name__}
    assert actual==expected and e.VERSION==REFERENCE_ENGINE_VERSION and e.ARCHITECTURE==ARCHITECTURE_ID
    results=reference_suite(cfg); assert len({r.config_hash for r in results})==1
    return {'status':'PASS','engine_version':e.VERSION,'architecture_id':e.ARCHITECTURE,
            'config_hash':e.config_hash(),'fingerprint':e.fingerprint(),
            'success_flags':{r.scenario:r.success for r in results}}

if __name__=='__main__':
    print(json.dumps(self_test(),ensure_ascii=False,indent=2))
    print('\nREFERENCE SUITE')
    for r in reference_suite():
        print(json.dumps({'scenario':r.scenario,'success':r.success,'metrics':r.metrics,
                          'engine':r.engine_version,'architecture':r.architecture_id,
                          'config_hash':r.config_hash},ensure_ascii=False))
