# DKA Lab Plug-in Contract v0.2

The lab UI talks to the host API, not to architecture internals. A future engine is integrated by adding a separate adapter/runner; the engine's source is not edited to satisfy the lab.

## Engine manifest
Each adapter must publish:
- `id`, `name`, `version`, `source_sha256`
- `capabilities`: explicit list drawn from `initialize`, `run`, `observe`, `learn`, `export_state`, `reset`
- `is_reference`, `mutable`, `runtime`, `limitations`

## Required host operations
- `initialize(config)`
- `run(task)` -> output/status/metrics/trace
- `reset()`

Optional operations must be declared. The host must not fabricate unsupported `learn`, `observe`, or `export_state` behavior.

## Isolation and trust
- The current local prototype runs only bundled trusted Python modules in one process. Do not load arbitrary third-party code into this process.
- For untrusted or externally supplied engines, run one engine per subprocess/container with time, memory, filesystem and network limits. Communicate through JSON Lines or HTTP with a versioned schema.
- Keep the frozen reference read-only; all changes go to a distinct experimental copy and must pass hash/integrity checks.
- The evaluator is outside the engine and receives the same task/conditions for paired comparisons.

## Learning evidence
A successful run is not evidence of learning. To claim learning, require feedback intervention, later held-out decisions, a no-feedback control, shuffled/inverted-feedback controls, paired seeds, and a record proving feedback -> memory/state update -> changed later decision. RA-1.3.3 currently declares `learn: false`.
